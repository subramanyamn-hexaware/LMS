import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primary-document',
  templateUrl: './primary-document.component.html',
  styleUrls: ['./primary-document.component.css']
})
export class PrimaryDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
