import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatButtonModule, MatCheckboxModule, MatMenuModule, MatNativeDateModule, MatTabsModule} from '@angular/material';
import { AppComponent } from './app.component';
import { DeltaPageComponent } from './delta-page/delta-page.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import {RouterModule} from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatDividerModule} from '@angular/material/divider';
import {MatListModule} from '@angular/material/list';
import {MatCardModule} from '@angular/material/card';
import {MatChipsModule} from '@angular/material/chips';
import {MatExpansionModule} from '@angular/material/expansion';
import { SampleComponent } from './sample/sample.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { SecureFlightComponent } from './secure-flight/secure-flight.component';
import { PrimaryDocumentComponent } from './primary-document/primary-document.component';
import { SecondaryDocumentComponent } from './secondary-document/secondary-document.component';

@NgModule({
  declarations: [
    AppComponent,
    DeltaPageComponent,
    SampleComponent,
    SecureFlightComponent,
    PrimaryDocumentComponent,
    SecondaryDocumentComponent
  ],
  imports: [
    BrowserModule,
    MatMenuModule,
    MatTabsModule,
    MatIconModule,
    MatChipsModule,
    MatSelectModule,
    MatExpansionModule,
    MatButtonModule,
    MatFormFieldModule,
    MatToolbarModule,
    MatInputModule,
    MatDatepickerModule,
    FlexLayoutModule,
    MatCheckboxModule,
    MatDividerModule,
    MatCardModule,
    MatListModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatNativeDateModule,
    RouterModule.forRoot ([
      { path: 'delta', component : DeltaPageComponent },
      { path: 'sample', component : SampleComponent },
      { path: 'secureFlight', component : SecureFlightComponent },
      { path: 'primaryDocument', component : PrimaryDocumentComponent },
      { path: 'secondaryDocument', component : SecondaryDocumentComponent },
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
