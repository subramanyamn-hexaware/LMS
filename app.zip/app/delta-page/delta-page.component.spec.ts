import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeltaPageComponent } from './delta-page.component';

describe('DeltaPageComponent', () => {
  let component: DeltaPageComponent;
  let fixture: ComponentFixture<DeltaPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeltaPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeltaPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
