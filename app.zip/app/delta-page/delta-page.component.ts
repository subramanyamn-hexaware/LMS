import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-delta-page',
  templateUrl: './delta-page.component.html',
  styleUrls: ['./delta-page.component.css']
})
export class DeltaPageComponent implements OnInit {
  passengers: string[] = [
    'Ben,David', 'Ben,Adam'
  ];
  constructor() {
  }
  ngOnInit() {
  }

}
