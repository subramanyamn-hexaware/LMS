import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecureFlightComponent } from './secure-flight.component';

describe('SecureFlightComponent', () => {
  let component: SecureFlightComponent;
  let fixture: ComponentFixture<SecureFlightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureFlightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
