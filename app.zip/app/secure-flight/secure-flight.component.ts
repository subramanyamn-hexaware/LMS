import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secure-flight',
  templateUrl: './secure-flight.component.html',
  styleUrls: ['./secure-flight.component.css']
})
export class SecureFlightComponent implements OnInit {
  genders: string[] = [
    'Male', 'Female', 'Other'
  ];
  constructor() {
  }

  ngOnInit() {
  }

}
