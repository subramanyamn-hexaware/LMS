import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryDocumentComponent } from './secondary-document.component';

describe('SecondaryDocumentComponent', () => {
  let component: SecondaryDocumentComponent;
  let fixture: ComponentFixture<SecondaryDocumentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryDocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
