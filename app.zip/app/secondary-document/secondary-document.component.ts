import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondary-document',
  templateUrl: './secondary-document.component.html',
  styleUrls: ['./secondary-document.component.css']
})
export class SecondaryDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
