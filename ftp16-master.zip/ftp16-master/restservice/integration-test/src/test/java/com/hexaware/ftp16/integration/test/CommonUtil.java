package com.hexaware.ftp16.integration.test;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;
import java.util.Date;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class CommonUtil {
    public static final String host;
    public static final String port;
    public static final String webapp;
    public static final String uri_prefix;
    static {
        host = System.getProperty("service.host", "localhost");
        port = System.getProperty("service.port", "8080");
        webapp = System.getProperty("service.webapp", "ftp16");
        uri_prefix = "http://" + host + ":" + port + "/" + webapp;
    }

    public static URI getURI(String path) throws URISyntaxException {
        return new URI(uri_prefix + path);
    }
}

class Employee {

    public int empId;
    private String empName; //empName to store employee Name
    private long empMobile; //empMobile to store employee Mobile
    private String empMail; //empMail to store employee Email
    private String empDept; //empDept to store employee Department
    private Date empJoinDate; //empJoinDate to store employee Joining date
    private int mgrId; //mgrId to store manager Id
    private float empLeavBal; //empLeavBal to store employee leave Balance

    /**
     * Default constructor for employee.
     */
    public Employee() {
    }

    /**
     * @param argEmpId to initialize employee id.
     */

    public Employee(final int argEmpId) {
        this.empId = argEmpId;
    }

    /**
     * @param argEmpId to initialize employee id.
     * @param argEmpName to initialize employee name.
     * @param argEmpMobile to initialize employee Mobile.
     * @param argEmpMail to initialize employee Mail.
     * @param argEmpDept to initialize employee Department.
     * @param argEmpJoinDate to initialize employee Joining date.
     * @param argMgrId to initialize employee Manager Id.
     * @param argEmpLeavBal to initialize employee LeaveBalance.
     */
    public Employee(final int argEmpId, final String argEmpName, final long argEmpMobile, final String argEmpMail,
            final String argEmpDept, final Date argEmpJoinDate, final int argMgrId, final float argEmpLeavBal) {
        this.empId = argEmpId;
        this.empName = argEmpName;
        this.empMobile = argEmpMobile;
        this.empMail = argEmpMail;
        this.empDept = argEmpDept;
        this.empJoinDate = argEmpJoinDate;
        this.mgrId = argMgrId;
        this.empLeavBal = argEmpLeavBal;
    }

    @Override
    public final boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Employee emp = (Employee) obj;
        if (Objects.equals(empId, emp.empId) && Objects.equals(empName, emp.empName)
                && Objects.equals(empMobile, emp.empMobile) && Objects.equals(empMail, emp.empMail)
                && Objects.equals(empDept, emp.empDept) && Objects.equals(empJoinDate, emp.empJoinDate)
                && Objects.equals(mgrId, emp.mgrId) && Objects.equals(empLeavBal, emp.empLeavBal)) {
            return true;
        }
        return false;
    }

    @Override
    public final int hashCode() {
        return Objects.hash(empId, empName, empDept, empJoinDate, empMail, empMobile, mgrId);
    }

    public String toString() {
        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            return ow.writeValueAsString(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Gets the EmployeeId.
     * @return this Employee's ID.
     */
    public final int getEmpId() {
        return empId;
    }

    /**
     * Gets the EmployeeName.
     * @return this Employee's Name.
     */
    public final String getEmpName() {
        return empName;
    }

    /**
     * Gets the EmployeeMobile.
     * @return this Employee's MobileNumber.
     */
    public final long getEmpMobile() {
        return empMobile;
    }

    /**
     * Gets the EmployeeMail.
     * @return this Employee's Email.
     */
    public final String getEmpMail() {
        return empMail;
    }

    /**
     * Gets the EmployeeDepartment.
     * @return this Employee's Department.
     */
    public final String getEmpDept() {
        return empDept;
    }

    /**
     * Gets the EmployeeJoiningDate.
     * @return this Employee's Joining Date.
     */
    public final Date getEmpJoinDate() {
        return empJoinDate;
    }

    /**
     * Gets the EmployeeManagerID.
     * @return this Employee's ManagerID.
     */
    public final int getMgrId() {
        return mgrId;
    }

    /**
     * Gets the Employee Leave Balance.
     * @return this Employee's Leave Balance.
     */
    public final float getEmpLeavBal() {
        return empLeavBal;
    }

    /**
     *
     * @param argEmpId to set employee id.
     */
    public final void setEmpId(final int argEmpId) {
        this.empId = argEmpId;
    }

    /**
     *
     * @param argEmpName to set employee Name.
     */
    public final void setEmpName(final String argEmpName) {
        this.empName = argEmpName;
    }

    /**
     *
     * @param argEmpMobile to set employee MobileNumber.
     */
    public final void setEmpMobile(final long argEmpMobile) {
        this.empMobile = argEmpMobile;
    }

    /**
     *
     * @param argEmpMail to set employee EmailId.
     */
    public final void setEmpMail(final String argEmpMail) {
        this.empMail = argEmpMail;
    }

    /**
     *
     * @param argEmpDept to set employee Department.
     */
    public final void setEmpDept(final String argEmpDept) {
        this.empDept = argEmpDept;
    }

    /**
     *
     * @param argEmpLeavBal to set employee Leave Balance.
     */
    public final void setEmpLeavBal(final float argEmpLeavBal) {
        this.empLeavBal = argEmpLeavBal;
    }

    /**
     *
     * @param argEmpJoinDate to set employee Joining date.
     */
    public final void setEmpJoinDate(final Date argEmpJoinDate) {
        this.empJoinDate = argEmpJoinDate;
    }

    /**
     *
     * @param argEmpMgrId to set employee ManagerId.
     */
    public final void setEmpMgrId(final int argEmpMgrId) {
        this.mgrId = argEmpMgrId;
    }

}

class LeaveDetails {

    /**
     *leavIdto store Leave id.
     */
    private int leavId;
    private Date leavFromDate; //fromdate to store fromdate
    private Date leavToDate; //to date to store todate
    private float noOfDays; //noOfDays to store noOfDays
    private Date appliedDate; //appliedDate to store Applied Date
    private LeaveStatus status; //status to store Status of Leave
    private String reason; //reason to store Reason for Leave
    private String comments; //comments to store Manager Comments
    private LeaveType leavType; //leavType to store Leave Type
    private int empId; //empId to store Employee Id

    @Override
    public final boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        LeaveDetails leav = (LeaveDetails) obj;
        if (Objects.equals(leavId, leav.leavId) && Objects.equals(leavFromDate, leav.leavFromDate)
                && Objects.equals(leavToDate, leav.leavToDate) && Objects.equals(noOfDays, leav.noOfDays)
                && Objects.equals(appliedDate, leav.appliedDate) && Objects.equals(status, leav.status)
                && Objects.equals(reason, leav.reason) && Objects.equals(comments, leav.comments)
                && Objects.equals(leavType, leav.leavType) && Objects.equals(empId, leav.empId)) {
            return true;
        }
        return false;
    }

    @Override
    public final int hashCode() {
        return Objects.hash(leavId, leavFromDate, leavToDate, noOfDays, appliedDate, status, reason, comments,
                leavType);
    }

    /**
     * @param argLeavId to initialize leave id.
     */
    public LeaveDetails(final int argLeavId) {
        this.leavId = argLeavId;
    }

    /**
     * LeaveDetails Default constructor.
     */
    public LeaveDetails() {
    }

    /**
     * @param argLeavId to initialize employee id.
     * @param argLeavFromDate to initialize employee name.
     * @param argLeavToDate to initialize employee Mobile.
     * @param argNoOfDays to initialize employee Mail.
     * @param argAppliedDate to initialize employee Department.
     * @param argStatus to initialize employee Joining date.
     * @param argReason to initialize employee Manager Id.
     * @param argComments to initialize employee LeaveBalance.
     * @param argLeavType to initialize employee LeaveType.
     * @param argempId to initialize employee Id.
     */
    public LeaveDetails(final int argLeavId, final Date argLeavFromDate, final Date argLeavToDate,
            final float argNoOfDays, final Date argAppliedDate, final LeaveStatus argStatus, final String argReason,
            final String argComments, final LeaveType argLeavType, final int argempId) {
        this.leavId = argLeavId;
        this.leavFromDate = argLeavFromDate;
        this.leavToDate = argLeavToDate;
        this.noOfDays = argNoOfDays;
        this.appliedDate = argAppliedDate;
        this.status = argStatus;
        this.reason = argReason;
        this.comments = argComments;
        this.leavType = argLeavType;
        this.empId = argempId;
    }

    /**
     * Gets the leave ID.
     * @return this LeaveID.
     */
    public final int getLeavId() {
        return leavId;
    }

    /**
     * Gets the empId.
     * @return this empId.
     */
    public final int getEmpId() {
        return empId;
    }

    /**
     * Gets the leave Type.
     * @return this LeaveType.
     */
    public final LeaveType getLeavType() {
        return leavType;
    }

    /**
     * Gets the LeaveFromDate.
     * @return this FromDate.
     */
    public final Date getLeavFromDate() {
        return leavFromDate;
    }

    /**
     * Gets the TO Date.
     * @return this To Date.
     */
    public final Date getLeavToDate() {
        return leavToDate;
    }

    /**
     * Gets the No of days.
     * @return this No Of Days.
     */
    public final float getNoOfDays() {
        return noOfDays;
    }

    /**
     * Gets the Leave Applied Date.
     * @return this Applied Date.
     */
    public final Date getAppliedDate() {
        return appliedDate;
    }

    /**
     * Gets the Status of Leave.
     * @return this Leave Status.
     */
    public final LeaveStatus getStatus() {
        return status;
    }

    /**
     * Gets the Reason For Leave.
     * @return this reason.
     */
    public final String getReason() {
        return reason;
    }

    /**
     * Gets the Comments From MAnager.
     * @return this Comments.
     */
    public final String getComments() {
        return comments;
    }

    /**
     *
     * @param argLeavId to set Leave Id.
     */
    public final void setleavId(final int argLeavId) {
        this.leavId = argLeavId;
    }

    /**
     *
     * @param argEmpId to set Employee Id.
     */
    public final void setEmpId(final int argEmpId) {
        this.empId = argEmpId;
    }

    /**
     *
     * @param argLeavType to set Leave Type.
     */
    public final void setLeavType(final LeaveType argLeavType) {
        this.leavType = argLeavType;
    }

    /**
     *
     * @param argLeavFromDate to set From Date.
     */
    public final void setFromDate(final Date argLeavFromDate) {
        this.leavFromDate = argLeavFromDate;
    }

    /**
     *
     * @param argLeavToDate to set To Date.
     */
    public final void setToDate(final Date argLeavToDate) {
        this.leavToDate = argLeavToDate;
    }

    /**
     *
     * @param argNoOfDays to set No Of Days.
     */
    public final void setNoOfDays(final float argNoOfDays) {
        this.noOfDays = argNoOfDays;
    }

    /**
     *
     * @param argAppliedDate to set Applied Date.
     */
    public final void setAppliedDate(final Date argAppliedDate) {
        this.appliedDate = argAppliedDate;
    }

    /**
     *
     * @param argStatus to set Status.
     */
    public final void setStatus(final LeaveStatus argStatus) {
        this.status = argStatus;
    }

    /**
     *
     * @param argReason to set Reason.
     */
    public final void setReason(final String argReason) {
        this.reason = argReason;
    }

    /**
     *
     * @param argComments to set Comments.
     */
    public final void setComments(final String argComments) {
        this.comments = argComments;
    }

    
    /**
     * List Leave details.
     * @return Leave Details.
     */

    public String toString() {
        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            return ow.writeValueAsString(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
enum LeaveStatus {

  /**
   * Types of Leave Status.
   */
  PENDING, APPROVED, DENIED
  }
  enum LeaveType {
    
    /**
     *Earned Leave.
      */
    EL;
  }      
