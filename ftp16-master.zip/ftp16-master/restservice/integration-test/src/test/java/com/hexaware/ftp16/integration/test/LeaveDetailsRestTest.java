package com.hexaware.ftp16.integration.test;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.net.URISyntaxException;


import com.jayway.restassured.response.Response;

import java.text.SimpleDateFormat;
import org.junit.Test;
import static org.junit.Assert.*;


import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.specification.RequestSpecification;

public class LeaveDetailsRestTest {

	@Test
	public void testApplyLeave() throws AssertionError, URISyntaxException {

        
      String res=given().accept(ContentType.JSON).contentType("application/json").body("{\"empId\":\"3000\",\"leavFromDate\":\"2019-12-09\",\"leavToDate\":\"2019-12-09\",\"noOfDays\":\"1.0\",\"reason\":\"sick\"}").
        when().post(CommonUtil.getURI("/api/leaveDetailsRestService/3000/applyforleave")).getBody().asString();
    
      assertEquals("Applied Leave sent for Approval.",res);
      assertEquals("You already applied leave in these dates.", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"3000\",\"leavFromDate\":\"2019-12-09\",\"leavToDate\":\"2019-12-09\",\"noOfDays\":\"1.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/3000/applyforleave")).getBody().asString());
    
      given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"3\",\"leavFromDate\":\"2019-12-09\",\"leavToDate\":\"2019-12-09\",\"noOfDays\":\"1.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/3/applyforleave")).then().assertThat().statusCode(404);

      assertEquals("Applied Leave has been Approved.", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-09\",\"leavToDate\":\"2019-11-09\",\"noOfDays\":\"1.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());

      assertEquals("End Date must be greater than Start Date", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-09\",\"leavToDate\":\"2019-11-07\",\"noOfDays\":\"3.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());
      assertEquals("You cannot apply leave for 0 days. Please enter valid Input", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-09\",\"leavToDate\":\"2019-11-07\",\"noOfDays\":\"0.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());
      assertEquals("Please enter a Positive value.", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-09\",\"leavToDate\":\"2019-11-07\",\"noOfDays\":\"-3.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());

      assertEquals("No Of Days does not match.", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-09\",\"leavToDate\":\"2019-11-11\",\"noOfDays\":\"5.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());

      assertEquals("You do not have sufficient leave balance to apply.", given().accept(ContentType.JSON).
                    contentType("application/json").body("{\"empId\":\"1000\",\"leavFromDate\":\"2019-11-01\",\"leavToDate\":\"2019-11-29\",\"noOfDays\":\"29.0\",\"reason\":\"sick\"}").
                            when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/applyforleave")).getBody().asString());
    }

    @Test
    
    public void testApproveDeny() throws AssertionError, URISyntaxException {
    
        
    
    String res1=given().accept(ContentType.JSON).contentType("application/json").body("{\"leavId\":\"8\",\"empId\":\"1000\",\"status\":\"APPROVED\",\"comments\":\"SICK\"}").
    when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/approvedeny")).getBody().asString(); 
    assertEquals("Status Updated from PENDING to APPROVED",res1);
    
    String res2=given().accept(ContentType.JSON).contentType("application/json").body("{\"leavId\":\"8\",\"empId\":\"1000\",\"status\":\"DENIED\",\"comments\":\"SICK\"}").
    when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/approvedeny")).getBody().asString(); 
    assertEquals("Leave Balance Updation on APPROVED to DENIED is Success",res2);
    
    String res3=given().accept(ContentType.JSON).contentType("application/json").body("{\"leavId\":\"8\",\"empId\":\"1000\",\"status\":\"APPROVED\",\"comments\":\"SICK\"}").
    when().post(CommonUtil.getURI("/api/leaveDetailsRestService/1000/approvedeny")).getBody().asString(); 
    assertEquals("Leave Balance Updation on DENIED to APPROVED is Success",res3);
    
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    @Test
	public void testPendingleaves() throws AssertionError, URISyntaxException {
		LeaveDetails[] res = given().accept(ContentType.JSON).when()
            .get(CommonUtil.getURI("/api/leaveDetailsRestService/1000/listPendingLeaves")).getBody()
                .as(LeaveDetails[].class);
        LeaveDetails l1=res[0];
        assertEquals(3, l1.getLeavId());
        assertEquals("2019-02-06", sdf.format(l1.getLeavFromDate()));
        assertEquals("2019-02-11", sdf.format(l1.getLeavToDate()));
    }
    @Test
	public void testPendindLeaveforNotaManager404() throws AssertionError, URISyntaxException {
		given().accept(ContentType.JSON).when()
                .get(CommonUtil.getURI("/api/leaveDetailsRestService/3001/listPendingLeaves")).then().assertThat()
                    .statusCode(404);
    }

    @Test
	public void testPendindLeaveForNoHistory404() throws AssertionError, URISyntaxException {
		given().accept(ContentType.JSON).when()
                .get(CommonUtil.getURI("/api/leaveDetailsRestService/2000/listPendingLeaves")).then().assertThat()
                    .statusCode(404);
    }
    
    @Test
    public void testLeaveDetailsList() throws AssertionError, URISyntaxException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        LeaveDetails[] res = given().accept(ContentType.JSON).when()
            .get(CommonUtil.getURI("/api/leaveDetailsRestService/2000/leaveHistory")).getBody().as(LeaveDetails[].class);
        LeaveDetails lev = res[0];
        assertEquals(3, lev.getLeavId());
        assertEquals("2018-02-20", sdf.format(lev.getLeavFromDate()));
        assertEquals("2018-02-12", sdf.format(lev.getLeavToDate()));
        assertEquals(3, lev.getNoOfDays(), 0);
        assertEquals("2018-02-09", sdf.format(lev.getAppliedDate()));
        assertEquals(LeaveStatus.DENIED, lev.getStatus());
        assertEquals("lazy", lev.getReason());
        assertEquals("be active", lev.getComments());
        assertEquals(LeaveType.EL, lev.getLeavType());
        assertEquals(2000, lev.getEmpId());

    }
    
      
    @Test
    public void testEmployeeById404() throws AssertionError, URISyntaxException {
        given().accept(ContentType.JSON).when()
                    .get(CommonUtil.getURI("/api/leaveDetailsRestService/4001/leaveHistory")).then().assertThat().statusCode(404);
    }

    
}
	
