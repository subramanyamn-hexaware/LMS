package com.hexaware.ftp16.model;

import com.hexaware.ftp16.persistence.DbConnection;
import com.hexaware.ftp16.persistence.EmployeeDAO;
import com.hexaware.ftp16.persistence.LeaveDetailsDAO;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import mockit.integration.junit4.JMockit;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.text.ParseException;

/**
 * Test class for Employee.
 */
@RunWith(JMockit.class)
public class EmployeeTest {

  /**
   * setup method.
   */
  @Before
  public void initInput() {

  }

  /**
   * Tests the equals/hashcode methods of the employee class.
   * @throws ParseException on invalid Dates.
   */
  @Test
  public final void testEmployee() throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Employee e100 = new Employee(100);
    Employee e101 = new Employee(101);
    assertNotEquals(e100, null);
    assertNotEquals(e100, new Integer(100));
    assertEquals(e100, new Employee(100));
    assertNotEquals(e101, new Employee(100));
    assertEquals(e100.getEmpId(), new Employee(100).getEmpId());
    e101.setEmpId(100);
    assertEquals(e101, new Employee(100));

    Employee e102 = new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"),
        100, 19);
    assertNotEquals(e102,
        new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"), 100, 20));
    assertEquals(e102,
        new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"), 100, 19));
    assertEquals(e102.hashCode(),
        new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"), 100, 19)
            .hashCode());
    LeaveDetails leaveDetails = new LeaveDetails(101);
    assertFalse(e102.equals(null));
    assertFalse(e102.equals(leaveDetails));
  }

  /**
   * Tests the toString method.
   * @throws ParseException on invalid Dates.
   */
  @Test
  public final void testToString() throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Employee e102 = new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"),
        100, 19);
    Employee e103 = new Employee(105, "Harry", 9632587415L, "harry@gmail.com", "HEXAVARSITY", sdf.parse("2002-05-06"),
        100, 19);
    String resultString = " EmpId: " + "105" + " EmpName: " + "Harry" + " EmpDept: " + "HEXAVARSITY"
        + " EmpJoiningDate: " + sdf.parse("2002-05-06") + " EmpMail: " + "harry@gmail.com" + " EmpMobile: "
        + "9632587415" + " MgrId: " + "100" + " EmpLeaveBal: " + "19";
    assertEquals(e102.toString(), e103.toString());
    assertEquals(e102.toString(), resultString);
  }

  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListAllEmpty(@Mocked final EmployeeDAO dao) {
    new Expectations() {
      {
        dao.list();
        result = new ArrayList<Employee>();
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] es = Employee.listAll();
    assertEquals(0, es.length);
  }

  /**
   * Tests that a list with some employees is handled correctly.
   * @param dao mocking the dao class
   * @throws ParseException on invalid dates.
   */
  @Test
  public final void testListAllSome(@Mocked final EmployeeDAO dao) throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
      {
        ArrayList<Employee> es = new ArrayList<Employee>();
        es.add(new Employee(1, "ABHI", 987654321L, "abhi@gmail.com", "FTP", sdf.parse("2017-12-27"), 10, 5f));
        es.add(new Employee(10, "AKSHATA", 963258741L, "akshata@gmail.com", "FTP", sdf.parse("2017-12-27"), 20, 7f));
        es.add(new Employee(100, "GOPI", 987456123L, "gopi@gmail.com", "FTP", sdf.parse("2017-12-27"), 10, 8f));
        dao.list();
        result = es;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] es = Employee.listAll();
    assertEquals(3, es.length);
    assertEquals(new Employee(1, "ABHI", 987654321L, "abhi@gmail.com", "FTP", sdf.parse("2017-12-27"), 10, 5f), es[0]);
    assertEquals(new Employee(10, "AKSHATA", 963258741L, "akshata@gmail.com", "FTP", sdf.parse("2017-12-27"), 20, 7f),
        es[1]);
    assertEquals(new Employee(100, "GOPI", 987456123L, "gopi@gmail.com", "FTP", sdf.parse("2017-12-27"), 10, 8f),
        es[2]);
  }

  /**
   * Tests Employee under a Manager.
   * @param dao mocking the dao class.
   *  @throws ParseException on invalid dates.
   */
  @Test
  public final void testListManager(@Mocked final EmployeeDAO dao) throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
      {
        ArrayList<Employee> su = new ArrayList<Employee>();
        su.add(new Employee(2, "ABHI", 987654321L, "abhi@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 5f));
        su.add(new Employee(10, "AKSHATA", 963258741L, "akshata@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 7f));
        su.add(new Employee(100, "GOPI", 987456123L, "gopi@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 8f));
        dao.findManager(1);
        result = su;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee[] emp = Employee.listManager(1);
    assertEquals(new Employee(2, "ABHI", 987654321L, "abhi@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 5f), emp[0]);
    assertEquals(new Employee(10, "AKSHATA", 963258741L, "akshata@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 7f),
        emp[1]);
    assertEquals(new Employee(100, "GOPI", 987456123L, "gopi@gmail.com", "FTP", sdf.parse("2017-12-27"), 1, 8f),
        emp[2]);
  }

  /**
   * Tests the updateLeave query functionality.
   * @param dao mocking the employee dao class
   */
  @Test
  public final void testUpdateLeave(@Mocked final EmployeeDAO dao) {
    new Expectations() {
      {
        dao.updateLeave(20f, 100);
        result = 1;
        dao.updateLeave(-5f, 100);
        result = 0;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    int updateResult = Employee.leaveBal(20f, 100);
    int updateResult1 = Employee.leaveBal(-5f, 100);
    assertEquals(1, updateResult);
    assertEquals(0, updateResult1);
  }

  /**
   * Tests that a fetch of a specific employee works correctly.
   * @param dao mocking the dao class
   */
  @Test
  public final void testListById(@Mocked final EmployeeDAO dao) {
    final Employee e100 = new Employee(100);
    new Expectations() {
      {
        dao.find(100);
        result = e100;
        dao.find(-1);
        result = null;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    Employee e = Employee.listById(100);
    assertEquals(e100, e);

    e = Employee.listById(-1);
    assertNull(e);
  }

  /**
   * Tests the getter setter methods of employee.
   * @throws ParseException on invalid dates.
   */
  @Test
  public final void testEmp() throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    final Employee employee = new Employee(100, "Tom", 9874561234L, "Tom@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 500, 24);
    employee.setEmpId(100);
    assertEquals(100, employee.getEmpId());
    assertNotEquals(200, employee.getEmpId());

    employee.setEmpName("Abhi");
    assertEquals("Abhi", employee.getEmpName());

    employee.setEmpMobile(9876543210L);
    assertEquals(9876543210L, employee.getEmpMobile());

    employee.setEmpMail("abhi@gmail.com");
    assertEquals("abhi@gmail.com", employee.getEmpMail());

    employee.setEmpDept("FTP");
    assertEquals("FTP", employee.getEmpDept());

    employee.setEmpLeavBal(10f);
    assertEquals(10f, employee.getEmpLeavBal(), 1);

    employee.setEmpJoinDate(sdf.parse("2017-12-27"));
    assertEquals(sdf.parse("2017-12-27"), employee.getEmpJoinDate());

    employee.setEmpMgrId(1000);
    assertEquals(1000, employee.getMgrId());
  }

  /**
   * Tests the getter setter methods of employee.
   * @param db mocks the DbConnection class
   */
  @Test(expected = NullPointerException.class)
  public final void testEmpDAO(@Mocked final DbConnection db) {
    new Expectations() {
      {
        db.getConnect();
        result = null;
      }
    };
    Employee.dao();
  }

  /**
   * Tests the getter setter methods of employee.
   * @param dao object of EmployeeDAO class
   * @param leaveDao object of LeaveDetailsDAO class
   * @throws Exception on invalid data.
   */
  @Test()
  public final void testApplyLeave(@Mocked final EmployeeDAO dao, @Mocked final LeaveDetailsDAO leaveDao)
      throws Exception {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    final Employee employee1 = new Employee(3000, "Tom", 9874561234L, "Tom@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 2000, 24);
    final Employee employee2 = new Employee(1000, "Harry", 9874561224L, "Harry@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 0, 24);
    final Employee employee3 = new Employee(2000, "Bonnie", 9874561274L, "Bonnie@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 1000, 24);
    final Employee employee4 = new Employee(2001, "Elena", 9874561273L, "Elena@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 1000, 0);
    final Employee employee5 = new Employee(2002, "Stefan", 9874561273L, "stefan@gmail.com", "HEXAVARSITY",
        sdf.parse("1995-10-12"), 1000, 24);
    final ArrayList<LeaveDetails> details = new ArrayList<LeaveDetails>();
    details.add(new LeaveDetails(1, sdf.parse("2018-02-07"), sdf.parse("2018-02-10"), 4f, sdf.parse("2018-02-01"),
                LeaveStatus.valueOf("PENDING"), "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 2000));
    details.add(new LeaveDetails(2, sdf.parse("2014-05-07"), sdf.parse("2014-05-10"), 4f, sdf.parse("2018-02-01"),
                LeaveStatus.valueOf("PENDING"), "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 2002));
    new Expectations() {
      {
        dao.find(2);
        result = null;
        dao.find(3000);
        result = employee1;
        dao.find(1000);
        result = employee2;
        dao.find(2000);
        result = employee3;
        dao.find(2002);
        result = employee5;
        dao.find(2001);
        result = employee4;
        leaveDao.updateBalance(23, 3000);
        result = 1;
        leaveDao.insert(LeaveType.valueOf("EL"), sdf.format(sdf.parse("2018-09-01")),
            sdf.format(sdf.parse("2018-09-01")), 1, "Sick", 3000, LeaveStatus.valueOf("PENDING"));
        result = 1;
        leaveDao.updateBalance(22, 1000);
        result = 1;
        leaveDao.insert(LeaveType.valueOf("EL"), sdf.format(sdf.parse("2018-09-02")),
            sdf.format(sdf.parse("2018-09-03")), 2, "Birthday Celebration", 1000, LeaveStatus.valueOf("APPROVED"));
        result = 1;
        leaveDao.insert(LeaveType.valueOf("EL"), sdf.format(sdf.parse("2018-09-02")),
            sdf.format(sdf.parse("2018-09-03")), 2, "Birthday Celebration", 2000, LeaveStatus.valueOf("PENDING"));
        result = 0;
        leaveDao.insert(LeaveType.valueOf("EL"), sdf.format(sdf.parse("2018-09-02")),
            sdf.format(sdf.parse("2018-09-03")), 2, "Birthday Celebration", 2002, LeaveStatus.valueOf("PENDING"));
        result = 1;
        leaveDao.updateBalance(22, 2002);
        result = 0;
        leaveDao.find(2002);
        result = details;
      }
    };

    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return leaveDao;
      }
    };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return dao;
      }
    };
    assertEquals("Sorry, No such employee",
                  Employee.applyLeaveValidation(2, "2018-09-01", "2018-09-01", 1, "Sick"));
    assertEquals("Applied Leave sent for Approval.",
                  Employee.applyLeaveValidation(3000, "2018-09-01", "2018-09-01", 1, "Sick"));
    assertEquals("Applied Leave has been Approved.",
                  Employee.applyLeaveValidation(1000, "2018-09-02", "2018-09-03", 2, "Birthday Celebration"));
    assertEquals("Updation Error",
                  Employee.applyLeaveValidation(2002, "2018-09-02", "2018-09-03", 2, "Birthday Celebration"));
    assertEquals("", Employee.applyLeaveValidation(2000, "2018-09-02", "2018-09-03", 2, "Birthday Celebration"));
    assertEquals("Enter Valid Date Format",
                  Employee.applyLeaveValidation(2002, "2018/09/02", "2018/09/03", 2, "Birthday Celebration"));
    assertEquals("End Date must be greater than Start Date",
                  Employee.applyLeaveValidation(2002, "2018-09-02", "2018-09-01", 2, "Birthday Celebration"));
    assertEquals("You cannot apply leave for 0 days. Please enter valid Input",
                  Employee.applyLeaveValidation(2002, "2018-09-02", "2018-09-03", 0, "Birthday Celebration"));
    assertEquals("Please enter a Positive value.",
                  Employee.applyLeaveValidation(2002, "2018-09-02", "2018-09-03", -4, "Birthday Celebration"));
    assertEquals("No Of Days does not match.",
                  Employee.applyLeaveValidation(2002, "2018-09-02", "2018-09-03", 7, "Birthday Celebration"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-07", "2014-05-10", 4, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-07", "2014-05-07", 1, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-10", "2014-05-10", 1, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-08", "2014-05-09", 2, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-07", "2014-05-09", 3, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-06", "2014-05-11", 6, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-10", "2014-05-12", 3, "Vacation"));
    assertEquals("You already applied leave in these dates.",
                    Employee.applyLeaveValidation(2002, "2014-05-05", "2014-05-08", 4, "Vacation"));
    assertEquals("You do not have sufficient leave balance to apply.",
                    Employee.applyLeaveValidation(2002, "2014-05-01", "2014-05-29", 29, "Vacation"));
    assertEquals("You do not have sufficient leave balance to apply.",
                    Employee.applyLeaveValidation(2001, "2014-05-01", "2014-05-05", 5, "Vacation"));
  }

}
