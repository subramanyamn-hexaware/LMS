package com.hexaware.ftp16.model;

import com.hexaware.ftp16.persistence.EmployeeDAO;
import com.hexaware.ftp16.persistence.LeaveDetailsDAO;

import java.text.SimpleDateFormat;
import java.text.ParseException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertFalse;

import org.junit.Test;


import mockit.Expectations;
import mockit.MockUp;
import mockit.Mocked;
import mockit.Mock;
import java.util.ArrayList;

/**
 * Test class for LeaveDetails.
 */
public class LeaveDetailsTest {

  /**
   * Tests the get,set methods of the LeaveDetails class.
   * @throws ParseException for invalid dates.
   */
  @Test
    public final void testLeavId() throws ParseException {

    final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");

    LeaveDetails obj98 = new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4f,
                                            sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                "enjoy", LeaveType.valueOf("EL"), 3000);

    LeaveDetails obj99 = new LeaveDetails(2, sf.parse("2018-03-22"), sf.parse("2018-03-28"), 7f,
                                                sf.parse("2018-02-08"), LeaveStatus.valueOf("APPROVED"), "bday21",
                                                    "enjoy21", LeaveType.valueOf("EL"), 3001);

    assertNotEquals(obj98, obj99);
    assertNotNull(obj98);

    LeaveDetails obj = new LeaveDetails(1);
    assertEquals(1, obj.getLeavId());
    obj.setleavId(3);
    assertEquals(3, obj.getLeavId());
    assertNotEquals(6, obj.getLeavId());

    obj.setEmpId(3000);
    assertEquals(3000, obj.getEmpId());
    assertNotEquals(3001, obj.getEmpId());

    obj.setLeavType(LeaveType.valueOf("EL"));
    assertEquals(LeaveType.valueOf("EL"), obj.getLeavType());
    assertNotEquals("ML", obj.getLeavType());

    obj.setFromDate(sf.parse("2018-03-21"));
    assertEquals("2018-03-21", sf.format(obj.getLeavFromDate()));
    assertNotEquals("2018-03-31", sf.format(obj.getLeavFromDate()));

    obj.setToDate(sf.parse("2018-03-24"));
    assertEquals("2018-03-24", sf.format(obj.getLeavToDate()));

    obj.setNoOfDays(4f);
    assertEquals(4f, obj.getNoOfDays(), 1);

    obj.setAppliedDate(sf.parse("2018-02-07"));
    assertEquals("2018-02-07", sf.format(obj.getAppliedDate()));

    obj.setStatus(LeaveStatus.valueOf("PENDING"));
    assertEquals(LeaveStatus.valueOf("PENDING"), obj.getStatus());

    obj.setReason("bday");
    assertEquals("bday", obj.getReason());

    obj.setComments("enjoy");
    assertEquals("enjoy", obj.getComments());

    LeaveDetails obj2 = new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4f,
                                            sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                "enjoy", LeaveType.valueOf("EL"), 3000);

    assertEquals(obj2, new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4f,
                                            sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"),
                                                "bday", "enjoy", LeaveType.valueOf("EL"), 3000));

    assertNotEquals(obj2, new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4f,
                                            sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                "enjoy", LeaveType.valueOf("EL"), 3001));
  }
  /**
   * Tests the approvedList method of the LeaveDetails class.
   * @param dao mocking the LeaveDetailsDAO class.
   * @param empDAO mocking the EmployeeDAO class.
   * @throws ParseException for invalid date format.
   */
  @Test
        public final void approvedListTest(@Mocked final LeaveDetailsDAO dao,
                                        @Mocked final EmployeeDAO empDAO) throws ParseException {
    final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
        {
          LeaveDetails levDet = new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3000);
          LeaveDetails levDet1 = new LeaveDetails(2, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3001);
          LeaveDetails levDet2 = new LeaveDetails(3, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("APPROVED"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3002);
          LeaveDetails levDet3 = new LeaveDetails(4, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("APPROVED"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3003);
          LeaveDetails levDet4 = new LeaveDetails(5, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("DENIED"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3004);
          LeaveDetails levDet5 = new LeaveDetails(6, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                    sf.parse("2018-02-07"), LeaveStatus.valueOf("DENIED"), "bday",
                                                        "enjoy", LeaveType.valueOf("EL"), 3005);
          dao.leaveApproveDeny(1, LeaveStatus.valueOf("APPROVED"), "enjoy");
          result = 1;
          dao.leaveApproveDeny(2, LeaveStatus.valueOf("DENIED"), "Sorry");
          result = 1;
          dao.leaveApproveDeny(3, LeaveStatus.valueOf("PENDING"), "Sorry");
          result = 1;
          dao.leaveApproveDeny(4, LeaveStatus.valueOf("DENIED"), "Sorry");
          result = 1;
          dao.leaveApproveDeny(5, LeaveStatus.valueOf("PENDING"), "Sorry");
          result = 1;
          dao.leaveApproveDeny(6, LeaveStatus.valueOf("APPROVED"), "Sorry");
          result = 1;
          dao.obtainLevById(1);
          result = levDet;
          dao.obtainLevById(2);
          result = levDet1;
          dao.obtainLevById(3);
          result = levDet2;
          dao.obtainLevById(4);
          result = levDet3;
          dao.obtainLevById(5);
          result = levDet4;
          dao.obtainLevById(6);
          result = levDet5;
          Employee empdet = new Employee(3000, "GOPI", 9878484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);
          Employee empdet1 = new Employee(3001, "KRISHNA", 9858484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);
          Employee empdet2 = new Employee(3002, "KRISHNA", 9858484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);
          Employee empdet3 = new Employee(3003, "KRISHNA", 9858484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);
          Employee empdet4 = new Employee(3004, "KRISHNA", 9858484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);
          Employee empdet5 = new Employee(3005, "KRISHNA", 9858484848L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 1000, 20);


          empDAO.find(3000);
          result = empdet;
          empDAO.find(3001);
          result = empdet1;
          empDAO.find(3002);
          result = empdet2;
          empDAO.find(3003);
          result = empdet3;
          empDAO.find(3004);
          result = empdet4;
          empDAO.find(3005);
          result = empdet5;
          empDAO.updateLeave(24, 3001);
          result = 1;
          empDAO.updateLeave(24, 3003);
          result = 1;
          empDAO.updateLeave(16, 3004);
          result = 1;
          empDAO.updateLeave(16, 3005);
          result = 1;
        }
      };

    new MockUp<LeaveDetails>() {
        @Mock
        LeaveDetailsDAO dao() {
        return dao;
        }
        };
    new MockUp<Employee>() {
        @Mock
        EmployeeDAO dao() {
        return empDAO;
        }
        };
    String result1 = LeaveDetails.approvedList(1, LeaveStatus.valueOf("APPROVED"), "enjoy");
    assertEquals("Status Updated from PENDING to APPROVED", result1);
    String result2 = LeaveDetails.approvedList(2, LeaveStatus.valueOf("DENIED"), "Sorry");
    assertEquals("Leave Balance Updation on PENDING to DENIED is Success", result2);
    String result3 = LeaveDetails.approvedList(3, LeaveStatus.valueOf("PENDING"), "Sorry");
    assertEquals("Status Updated from APPROVED to PENDING", result3);
    String result4 = LeaveDetails.approvedList(4, LeaveStatus.valueOf("DENIED"), "Sorry");
    assertEquals("Leave Balance Updation on APPROVED to DENIED is Success", result4);
    String result5 = LeaveDetails.approvedList(5, LeaveStatus.valueOf("PENDING"), "Sorry");
    assertEquals("Leave Balance Updation on DENIED to PENDING is Success", result5);
    String result6 = LeaveDetails.approvedList(6, LeaveStatus.valueOf("APPROVED"), "Sorry");
    assertEquals("Leave Balance Updation on DENIED to APPROVED is Success", result6);

  }

  /**
   * Tests that a list with some leavedetails is handled correctly.
   * @param dao mocking the dao class.
   * @throws ParseException thrown on invalid dates.
   */
  @Test
  public final void testPendingList(@Mocked final LeaveDetailsDAO dao) throws ParseException {
    final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
      {
        ArrayList<LeaveDetails> pl = new ArrayList<LeaveDetails>();
        pl.add(new LeaveDetails(10, sf.parse("2018-07-02"), sf.parse("2018-07-16"), 10f, sf.parse("2018-07-05"),
            LeaveStatus.valueOf("PENDING"), "Out of station", "fine", LeaveType.valueOf("EL"), 2000));
        pl.add(new LeaveDetails(50, sf.parse("2018-06-02"), sf.parse("2018-06-16"), 10f, sf.parse("2018-06-05"),
            LeaveStatus.valueOf("APPROVED"), "Not feeling well", "Take Care", LeaveType.valueOf("EL"), 2001));
        pl.add(new LeaveDetails(30, sf.parse("2018-05-02"), sf.parse("2018-05-16"), 10f, sf.parse("2018-05-05"),
            LeaveStatus.valueOf("PENDING"), "Wedding", "Congratulations", LeaveType.valueOf("EL"), 3001));
        dao.findPendingLeave(1); result = pl;
      }
    };
    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return dao;
      }
    };
    LeaveDetails[] pl = LeaveDetails.pendingList(1);
    assertEquals(3, pl.length);
    assertEquals(new LeaveDetails(10, sf.parse("2018-07-02"), sf.parse("2018-07-16"), 10f, sf.parse("2018-07-05"),
        LeaveStatus.valueOf("PENDING"), "Out of station", "fine", LeaveType.valueOf("EL"), 2000), pl[0]);
    assertEquals(new LeaveDetails(50, sf.parse("2018-06-02"), sf.parse("2018-06-16"), 10f, sf.parse("2018-06-05"),
        LeaveStatus.valueOf("APPROVED"), "Not feeling well", "Take Care", LeaveType.valueOf("EL"), 2001), pl[1]);
    assertEquals(new LeaveDetails(30, sf.parse("2018-05-02"), sf.parse("2018-05-16"), 10f, sf.parse("2018-05-05"),
        LeaveStatus.valueOf("PENDING"), "Wedding", "Congratulations", LeaveType.valueOf("EL"), 3001), pl[2]);
  }


 /** Tests that a fetch of a specific LeaveHistory works correctly.
   * @param dao mocking the dao class
   * @throws ParseException catches the date parsing exception.
   */
  @Test
    public final void testlisthistory(@Mocked final LeaveDetailsDAO dao) throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
    new Expectations() {
        {
          ArrayList<LeaveDetails> al = new ArrayList<LeaveDetails>();
          al.add(new LeaveDetails(120, sdf.parse("2018-02-08"), sdf.parse("2018-02-10"), 2.0f, sdf.parse("2018-02-07"),
                                    LeaveStatus.PENDING, "sick", "enjoy", LeaveType.EL, 2000));
          al.add(new LeaveDetails(100, sdf.parse("2018-02-09"), sdf.parse("2018-02-12"), 3.0f, sdf.parse("2018-02-08"),
                                    LeaveStatus.APPROVED, "casual", "dare", LeaveType.EL, 3000));
          al.add(new LeaveDetails(300, sdf.parse("2018-02-10"), sdf.parse("2018-02-14"), 4.0f, sdf.parse("2018-02-09"),
                                    LeaveStatus.DENIED, "casual", "dare", LeaveType.EL, 3001));
          dao.find(2000); result = al;

        }
    };
    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return dao;
      }
    };

    LeaveDetails[] ld = LeaveDetails.listhistory(2000);
    assertEquals(3, ld.length);
    assertEquals(new LeaveDetails(120, sdf.parse("2018-02-08"), sdf.parse("2018-02-10"), 2.0f, sdf.parse("2018-02-07"),
          LeaveStatus.PENDING, "sick", "enjoy", LeaveType.EL, 2000), ld[0]);
    assertEquals(new LeaveDetails(100, sdf.parse("2018-02-09"), sdf.parse("2018-02-12"), 3.0f, sdf.parse("2018-02-08"),
          LeaveStatus.APPROVED, "casual", "dare", LeaveType.EL, 3000), ld[1]);
    assertEquals(new LeaveDetails(300, sdf.parse("2018-02-10"), sdf.parse("2018-02-14"), 4.0f, sdf.parse("2018-02-09"),
          LeaveStatus.DENIED, "casual", "dare", LeaveType.EL, 3001), ld[2]);
    assertNotEquals(new LeaveDetails(120, sdf.parse("2018-02-08"), sdf.parse("2018-02-10"), 2.0f,
                                        sdf.parse("2018-02-07"), LeaveStatus.PENDING, "sick", "enjoy", LeaveType.EL,
                                            2000), ld[2]);
    assertNotEquals(new LeaveDetails(300, sdf.parse("2018-02-10"), sdf.parse("2018-02-14"), 4.0f,
                                        sdf.parse("2018-02-09"), LeaveStatus.DENIED, "casual", "dare", LeaveType.EL,
                                            3001), ld[1]);
  }

  /**
   * Tests the Equals() method.
   * @throws ParseException catches the date parsing exception.
   */
  @Test
  public final void testEquals() throws ParseException {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
    LeaveDetails l = new LeaveDetails(120, sdf.parse("2018-02-08"), sdf.parse("2018-02-10"), 2.0f,
                                            sdf.parse("2018-02-07"), LeaveStatus.PENDING, "sick", "enjoy",
                                                LeaveType.EL, 2000);
    assertNotEquals(l, new Integer(100));
    assertFalse(l.equals(null));
  }
  /**
   * Tests the LeaveDetailsDAO.
   */
  @Test
  public final void testLeaveDetailsDAO() {
    LeaveDetailsDAO ldd = LeaveDetails.dao();
    assertNotNull(ldd);
  }

  /**
   * tests that empty employee list is handled correctly.
   * @param dao mocking the dao class
   * @throws ParseException on invalid date format.
   */
  @Test
  public final void testListId(@Mocked final LeaveDetailsDAO dao) throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
      {
        LeaveDetails lev = new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                              sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                                  "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100);
        LeaveDetails lev2 = new LeaveDetails(2, sdf.parse("2018-02-05"), sdf.parse("2018-02-10"), 4f,
                                              sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                                  "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100);
        dao.obtainLevById(1);
        result = lev;
        dao.obtainLevById(2);
        result = lev2;
        dao.obtainLevById(3);
        result = null;
      }
    };

    new MockUp<LeaveDetails>() {
        @Mock
        LeaveDetailsDAO dao() {
          return dao;
        }
    };


    LeaveDetails result1 = LeaveDetails.listId(1);
    LeaveDetails result2 = LeaveDetails.listId(2);
    LeaveDetails result3 = LeaveDetails.listId(3);
    assertEquals(result1, new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                            sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                                "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100));
    assertEquals(result2, new LeaveDetails(2, sdf.parse("2018-02-05"), sdf.parse("2018-02-10"), 4f,
                                            sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                                "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100));
    assertEquals(null, result3);
  }

  /**
   * Tests the toString method.
   * @throws ParseException on invalid Dates.
   */
  @Test
  public final void testToString() throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    LeaveDetails lev = new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                          sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                            "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100);
    LeaveDetails lev1 = new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                          sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                            "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100);
    String resultString = 1 + " \t\t " +  "EL" + " \t\t " + sdf.parse("2018-02-01") + " \t " + sdf.parse("2018-02-04")
                            + " \t " + 4 + " \t\t " + sdf.parse("2018-02-01") + " \t " + "PENDING" + " \t "
                                + "SICK LEAVE" + " \t\t " + "ENJOY" + " \t " + 100;
    assertEquals(lev.toString(), lev1.toString());
    assertEquals(lev.toString(), resultString);
  }

  /**
   * Tests the hashcode methods of the LeaveDetails class.
   * @throws ParseException on invalid Dates.
   */
  @Test
  public final void testLeaveDetails() throws ParseException {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    LeaveDetails lev = new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                        sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                            "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100);
    assertEquals(lev.hashCode(), (new LeaveDetails(1, sdf.parse("2018-02-01"), sdf.parse("2018-02-04"), 4f,
                                                    sdf.parse("2018-02-01"), LeaveStatus.valueOf("PENDING"),
                                                     "SICK LEAVE", "ENJOY", LeaveType.valueOf("EL"), 100).hashCode()));
  }

/**
   * Tests the hashcode methods of the LeaveDetails class.
   * @param dao for LeaveDetailsDAO.
   * @param empDAO for Employee DAO.
   * @throws ParseException on invalid Dates.
   * @throws IllegalArgumentException on invalid Data.
   */
  @Test
  public final void testApproveDenyValidations(@Mocked final LeaveDetailsDAO dao, @Mocked final EmployeeDAO empDAO)
                                                throws ParseException {
    final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
    new Expectations() {
      {
        ArrayList<Employee> es = new ArrayList<Employee>();
        es.add(new Employee(3000, "Gopi", 9701775241L, "gk.alladi", "hexavarsity",
                                            sf.parse("2015-03-24"), 2000, 20));
        es.add(new Employee(3001, "Gopi", 9701775241L, "gk.alladi", "hexavarsity",
                              sf.parse("2015-03-24"), 3000, 20));

        empDAO.findManager(3000);
        result = es;

        LeaveDetails levDet = new LeaveDetails(1, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                sf.parse("2018-02-07"), LeaveStatus.valueOf("PENDING"), "bday",
                                                  "enjoy", LeaveType.valueOf("EL"), 3000);
        LeaveDetails levDet2 = new LeaveDetails(3, sf.parse("2018-03-21"), sf.parse("2018-03-24"), 4,
                                                sf.parse("2018-02-07"), LeaveStatus.valueOf("APPROVED"), "bday",
                                                  "enjoy", LeaveType.valueOf("EL"), 3000);
        dao.findLeavId(1);
        result = levDet;
        dao.findLeavId(3);
        result = levDet2;
      }
    };
    new MockUp<LeaveDetails>() {
      @Mock
      LeaveDetailsDAO dao() {
        return dao;
      }
      };
    new MockUp<Employee>() {
      @Mock
      EmployeeDAO dao() {
        return empDAO;
      }
      };
    String result3 = LeaveDetails.approveDenyValidation(3, 3000, "APPROVED", "enjoy");
    assertEquals("You are not eligible to approve/deny to this leave Id", result3);
    String result4 = LeaveDetails.approveDenyValidation(1, 2000, "APPROVED", "");
    assertEquals("Please enter comments", result4);
    String result5 = LeaveDetails.approveDenyValidation(1, 2000, "PENDING", "ok");
    assertEquals("The status is already PENDING", result5);
    String result6 = LeaveDetails.approveDenyValidation(4, 3001, "APPROVED", "gopi");
    assertEquals("You are not having any reporting employees", result6);
  }
}
