package com.hexaware.ftp16.model;

import com.hexaware.ftp16.persistence.LeaveDetailsDAO;
import com.hexaware.ftp16.persistence.DbConnection;

import java.util.Objects;
import java.util.Date;
import java.util.List;

/**
 * LeaveDetails class to store employee leave details.
 * @author hexware
 */
public class LeaveDetails {

  /**
   *leavIdto store Leave id.
   */
  private int leavId;
  private Date leavFromDate; //fromdate to store fromdate
  private Date leavToDate; //to date to store todate
  private float noOfDays; //noOfDays to store noOfDays
  private Date appliedDate; //appliedDate to store Applied Date
  private LeaveStatus status; //status to store Status of Leave
  private String reason; //reason to store Reason for Leave
  private String comments; //comments to store Manager Comments
  private LeaveType leavType; //leavType to store Leave Type
  private int empId; //empId to store Employee Id

  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    LeaveDetails leav = (LeaveDetails) obj;
    if (Objects.equals(leavId, leav.leavId) && Objects.equals(leavFromDate, leav.leavFromDate)
        && Objects.equals(leavToDate, leav.leavToDate) && Objects.equals(noOfDays, leav.noOfDays)
         && Objects.equals(appliedDate, leav.appliedDate) && Objects.equals(status, leav.status)
          && Objects.equals(reason, leav.reason) && Objects.equals(comments, leav.comments)
            && Objects.equals(leavType, leav.leavType) && Objects.equals(empId, leav.empId)) {
      return true;
    }
    return false;
  }

  @Override
  public final int hashCode() {
    return Objects.hash(leavId, leavFromDate, leavToDate, noOfDays, appliedDate, status, reason, comments, leavType);
  }

  /**
   * @param argLeavId to initialize leave id.
   */
  public LeaveDetails(final int argLeavId) {
    this.leavId = argLeavId;
  }

  /**
   * LeaveDetails Default constructor.
   */
  public LeaveDetails() {
  }

  /**
   * @param argLeavId to initialize employee id.
   * @param argLeavFromDate to initialize employee name.
   * @param argLeavToDate to initialize employee Mobile.
   * @param argNoOfDays to initialize employee Mail.
   * @param argAppliedDate to initialize employee Department.
   * @param argStatus to initialize employee Joining date.
   * @param argReason to initialize employee Manager Id.
   * @param argComments to initialize employee LeaveBalance.
   * @param argLeavType to initialize employee LeaveType.
   * @param argempId to initialize employee Id.
   */
  public LeaveDetails(final int argLeavId, final Date argLeavFromDate,
                        final Date argLeavToDate, final float argNoOfDays,
                            final Date argAppliedDate, final LeaveStatus argStatus,
                                final String argReason, final String argComments,
                                    final LeaveType argLeavType, final int argempId) {
    this.leavId = argLeavId;
    this.leavFromDate = argLeavFromDate;
    this.leavToDate = argLeavToDate;
    this.noOfDays = argNoOfDays;
    this.appliedDate = argAppliedDate;
    this.status = argStatus;
    this.reason = argReason;
    this.comments = argComments;
    this.leavType = argLeavType;
    this.empId = argempId;
  }

  /**
   * list employee details by id.
   * @param levId id to get employee details.
   * @return LeaveDetails
   */
  public static LeaveDetails listId(final int levId) {
    return dao().obtainLevById(levId);
  }

  /**
  * @param leavId to get leave id.
  * @param status to get status.
  * @param cmnts to get comments.
  * @return Update Result
  */
  public static String approvedList(final int leavId, final LeaveStatus status, final String cmnts) {
    String result = "";
    LeaveDetails le = LeaveDetails.listId(leavId);
    LeaveStatus dbStatus = le.getStatus();
    if (status == dbStatus) {
      throw new IllegalArgumentException("The status is already " + dbStatus);
    }
    int res = dao().leaveApproveDeny(leavId, status, cmnts);
    if (res > 0) {
      result = "Status Updated from " + dbStatus + " to " + status;
      int empId = le.getEmpId();
      Employee e = Employee.listById(empId);
      float noOfDays = le.getNoOfDays();
      float leavAvalBal = 0f;
      if (status == LeaveStatus.DENIED
            && (dbStatus == LeaveStatus.PENDING || dbStatus == LeaveStatus.APPROVED)) {
        leavAvalBal = e.getEmpLeavBal() + noOfDays;
        int updateResult1 = Employee.leaveBal(leavAvalBal, empId);
        if (updateResult1 > 0) {
          result = "Leave Balance Updation on " + dbStatus + " to " + status + " is Success";
        }
      } else if ((status == LeaveStatus.PENDING || status == LeaveStatus.APPROVED)
                  && dbStatus == LeaveStatus.DENIED) {
        leavAvalBal = e.getEmpLeavBal() - noOfDays;
        int updateResult1 = Employee.leaveBal(leavAvalBal, empId);
        if (updateResult1 > 0) {
          result = "Leave Balance Updation on " + dbStatus + " to " + status + " is Success";
        }
      }
    }
    return result;
  }

  /**
  * @param leavId to get leave id.
  * @param userStatus to get status.
  * @param cmnts to get comments.
  * @param empId to get details of particular employee.
  * @throws IllegalArgumentException to catch exception.
  * @return Update Result
  */
  public static String approveDenyValidation(final int leavId, final int empId, final String userStatus,
                                              final String cmnts) {
    String result = "";
    String uStatus = "";
    Employee[] employee1 = Employee.listManager(empId);
    if (employee1.length == 0) {
      result = "You are not having any reporting employees";
    } else {
      LeaveDetails ldl = LeaveDetails.listByLeavId(leavId);
      if (ldl == null) {
        result = "Sorry, No such Leave ID";
      } else {
        int leavEmpId = ldl.getEmpId();
        Employee empDetails = Employee.listById(leavEmpId);
        if (empDetails.getMgrId() == empId) {
          LeaveStatus dbStatus = ldl.getStatus();
          if (userStatus.equalsIgnoreCase("approved") || userStatus.equalsIgnoreCase("denied")
              || userStatus.equalsIgnoreCase("pending")) {
            uStatus = userStatus.toUpperCase();
            LeaveStatus status = LeaveStatus.valueOf(uStatus);
            if (status == dbStatus) {
              result = "The status is already " + dbStatus;
            } else {
              if (cmnts.isEmpty()) {
                result = "Please enter comments";
              } else {
                result = LeaveDetails.approvedList(leavId, status, cmnts);
              }
            }
          } else {
            result = "Enter Valid Status";
          }
        } else {
          result = "You are not eligible to approve/deny to this leave Id";
        }
      }
    }

    return result;
  }

  /**
   * Gets the leave ID.
   * @return this LeaveID.
   */
  public final int getLeavId() {
    return leavId;
  }

  /**
   * Gets the empId.
   * @return this empId.
   */
  public final int getEmpId() {
    return empId;
  }

  /**
   * Gets the leave Type.
   * @return this LeaveType.
   */
  public final LeaveType getLeavType() {
    return leavType;
  }

  /**
   * Gets the LeaveFromDate.
   * @return this FromDate.
   */
  public final Date getLeavFromDate() {
    return leavFromDate;
  }

  /**
   * Gets the TO Date.
   * @return this To Date.
   */
  public final Date getLeavToDate() {
    return leavToDate;
  }

  /**
   * Gets the No of days.
   * @return this No Of Days.
   */
  public final float getNoOfDays() {
    return noOfDays;
  }

  /**
   * Gets the Leave Applied Date.
   * @return this Applied Date.
   */
  public final Date getAppliedDate() {
    return appliedDate;
  }

  /**
   * Gets the Status of Leave.
   * @return this Leave Status.
   */
  public final LeaveStatus getStatus() {
    return status;
  }

  /**
   * Gets the Reason For Leave.
   * @return this reason.
   */
  public final String getReason() {
    return reason;
  }

  /**
   * Gets the Comments From MAnager.
   * @return this Comments.
   */
  public final String getComments() {
    return comments;
  }

  /**
   *
   * @param argLeavId to set Leave Id.
   */
  public final void setleavId(final int argLeavId) {
    this.leavId = argLeavId;
  }

  /**
   *
   * @param argEmpId to set Employee Id.
   */
  public final void setEmpId(final int argEmpId) {
    this.empId = argEmpId;
  }

  /**
   *
   * @param argLeavType to set Leave Type.
   */
  public final void setLeavType(final LeaveType argLeavType) {
    this.leavType = argLeavType;
  }

  /**
   *
   * @param argLeavFromDate to set From Date.
   */
  public final void setFromDate(final Date argLeavFromDate) {
    this.leavFromDate = argLeavFromDate;
  }

  /**
   *
   * @param argLeavToDate to set To Date.
   */
  public final void setToDate(final Date argLeavToDate) {
    this.leavToDate = argLeavToDate;
  }

  /**
   *
   * @param argNoOfDays to set No Of Days.
   */
  public final void setNoOfDays(final float argNoOfDays) {
    this.noOfDays = argNoOfDays;
  }

  /**
   *
   * @param argAppliedDate to set Applied Date.
   */
  public final void setAppliedDate(final Date argAppliedDate) {
    this.appliedDate = argAppliedDate;
  }

  /**
   *
   * @param argStatus to set Status.
   */
  public final void setStatus(final LeaveStatus argStatus) {
    this.status = argStatus;
  }

  /**
   *
   * @param argReason to set Reason.
   */
  public final void setReason(final String argReason) {
    this.reason = argReason;
  }

  /**
   *
   * @param argComments to set Comments.
   */
  public final void setComments(final String argComments) {
    this.comments = argComments;
  }

/**
   * list LeaveDetails by leave id.
   * @param leavId id to get LeaveDetails.
   * @return LeaveDetails
   */
  public static LeaveDetails listByLeavId(final int leavId) {
    return dao().findLeavId(leavId);
  }

  /**
   * List pending leave details.
   * @param empId to get employee Leave details.
   * @return Leave details.
   */

  public static LeaveDetails[] pendingList(final int empId) {
    List<LeaveDetails> ld = dao().findPendingLeave(empId);
    return ld.toArray(new LeaveDetails[ld.size()]);
  }
  /**
   * List Leave details.
   * @return Leave Details.
   */

  public final String toString() {
    return  leavId + " \t\t " +  leavType + " \t\t " + leavFromDate + " \t " + leavToDate
                     + " \t " + (int) noOfDays + " \t\t " + appliedDate + " \t " + status + " \t " + reason
                       + " \t\t " + comments + " \t " + empId;
  }

/**
 * list leavedetails details by id.
 * @param employeelevid id to get employee details.
 * @return LeaveDetails
 */
  public static LeaveDetails[] listhistory(final int employeelevid) {
    List<LeaveDetails> es = dao().find(employeelevid);
    return es.toArray(new LeaveDetails[es.size()]);
  }
  /**
   * @return The dao for leaveDetails.
   */
  public static LeaveDetailsDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(LeaveDetailsDAO.class);
  }


}
