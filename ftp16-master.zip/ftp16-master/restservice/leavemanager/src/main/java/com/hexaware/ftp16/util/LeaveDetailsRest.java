package com.hexaware.ftp16.util;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;

import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import java.text.SimpleDateFormat;

import com.hexaware.ftp16.model.LeaveDetails;
import com.hexaware.ftp16.model.Employee;

/**
 * This class provides a rest interface for the leave details entity.
 */
@Path("/leaveDetailsRestService")
public class LeaveDetailsRest {
  /**
   * @return the leave history of the employee.
   * @param empId to check leave history for a particular employee.
   */
  @GET
  @Path("{empId}/leaveHistory")
  @Produces(MediaType.APPLICATION_JSON)
  public final LeaveDetails[] listEmpLevhistory(@PathParam("empId") final int empId) {
    LeaveDetails[] leavedetails;
    Employee employee = Employee.listById(empId);
    if (employee == null) {
      throw new NotFoundException("Sorry, No such employee");
    } else {
      leavedetails = LeaveDetails.listhistory(empId);
      if (leavedetails.length == 0) {
        throw new NotFoundException("No Leave History exists");
      } else {
        return leavedetails;
      }
    }
  }

  /**
   * Returns a specific employee's details.
   * @param empId the id of the employee
   * @return the Leave details
   * (Employee.listManager(id) == null)
   * @throws NotFoundException on wrond data.
   */
  @GET
  @Path("{empId}/listPendingLeaves")
  @Produces(MediaType.APPLICATION_JSON)
  public final LeaveDetails[] pendingleaves(@PathParam("empId") final int empId) {
    final Employee employee = Employee.listById(empId);
    if (employee == null) {
      throw new NotFoundException("No such Employee ID " + empId);
    }
    if (Employee.listManager(empId) == null) {
      throw new NotFoundException("You are not a Manager " + empId);
    } else {
      final LeaveDetails[] leav = LeaveDetails.pendingList(empId);
      if (leav.length == 0) {
        throw new NotFoundException("You don't have any pending leaves " + empId);
      } else {
        return leav;
      }
    }
  }

  /**
   * @param id Employee Id to apply leave.
   * @param leav LeaveDetails object to obtain data.
   * @return Applied Leave Status.
   * @throws Exception on incorrect dates.
   */
  @POST
  @Path("{id}/applyforleave")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public final String applyForLeave(@PathParam("id") final int id, final LeaveDetails leav)
                                        throws Exception {
    String msg = null;
    System.out.println("Apply for Leave");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    final Employee empl = Employee.listById(id);
    if (empl == null) {
      throw new NotFoundException("No such Employee ID: " + id);
    } else {
      msg = Employee.applyLeaveValidation(leav.getEmpId(), sdf.format(leav.getLeavFromDate()),
                                  sdf.format(leav.getLeavToDate()), (int) leav.getNoOfDays(), leav.getReason());
    }
    return msg;
  }

  /**
  * Returns a list of the leavedetails of employees.
  * @return a list ofleavedetails of employees.
  * @throws IllegalArgumentException when exception occurs.
  * @param id to list Employee Id.
  * @param leave to get the values.
  */

  @POST
  @Path("/{id}/approvedeny")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
    public final String approvedeny(@PathParam("id") final int id, final LeaveDetails leave)
                                      throws IllegalArgumentException {
    final Employee empl = Employee.listById(id);
    String store = "";
    if  (empl == null) {
      throw new NotFoundException("No such Employee ID: " + id);
    } else {
      store = LeaveDetails.approveDenyValidation(leave.getLeavId(), leave.getEmpId(),
                                                      leave.getStatus().name(), leave.getComments());
    }
    return store;
  }

}



