package com.hexaware.ftp16.persistence;

import com.hexaware.ftp16.model.LeaveDetails;
import com.hexaware.ftp16.model.LeaveType;
import com.hexaware.ftp16.model.LeaveStatus;
import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
/**
 * The DAO class for Leave details.
 */
public interface LeaveDetailsDAO  {
  /**
   * return all the details of all the employees.
   * @param leavId to check leave id.
   * @param status to check leave status.
   * @param comments to give comments.
   * @return the updation result
   */
  @SqlUpdate("UPDATE LEAVE_DETAILS SET LEV_STATUS=:leav_status, LEV_COMMENTS=:mgrComments WHERE LEV_ID= :leavId")
  int leaveApproveDeny(@Bind("leavId") int leavId, @Bind("leav_status") LeaveStatus status,
                        @Bind("mgrComments") String comments);


  /**
   * return all the leave details of the selected employee.
   * @param empId the id of the employee Manager.
   * @return the employee manager object.
   */
  @SqlQuery("select l.* from employee e,leave_details l where l.lev_status = 'PENDING'"
              + "and e.mgr_id= :empId and e.emp_id = l.emp_id")
  @Mapper(LeaveDetailsMapper.class)
  List<LeaveDetails> findPendingLeave(@Bind("empId") int empId);



  /**
   * return all the details of the selected employee.
   * @param employeelevid the id of the employee
   * @return the LeaveDetails object
   */
  @SqlQuery("SELECT * FROM LEAVE_DETAILS WHERE EMP_ID=:employeelevid")
  @Mapper(LeaveDetailsMapper.class)
  List<LeaveDetails> find(@Bind("employeelevid") int employeelevid);

    /**
     * @return returns the Insertion result.
     * @param empId the id of the employee.
     * @param levType the leaveType of the leave.
     * @param fromDate the start date of leave.
     * @param toDate the end date of leave.
     * @param days the no of days leave applied.
     * @param levStatus the status of the leave applied.
     * @param reason leave reason.
     */
  @SqlUpdate("Insert into LEAVE_DETAILS(LEV_TYPE,LEV_FROM_DATE,LEV_TO_DATE,LEV_NO_OF_DAYS,LEV_REASON,EMP_ID,LEV_STATUS)"
                    + " values (:levTyp, :fromDate, :toDate, :days, :reason, :empId, :status)")
    int insert(@Bind("levTyp") LeaveType levType, @Bind("fromDate") String fromDate, @Bind("toDate") String toDate,
                @Bind("days") int days, @Bind("reason") String reason, @Bind("empId") int empId,
                  @Bind("status") LeaveStatus levStatus);

    /**
     * return all the details of the selected leave.
     * @param levId the id of the applied leaves.
     * @return the LeaveDetails object
     */
  @SqlQuery("SELECT * FROM LEAVE_DETAILS WHERE LEV_ID = :levId")
  @Mapper(LeaveDetailsMapper.class)
  LeaveDetails obtainLevById(@Bind("levId") int levId);
  /**
   * return all the details of the selected Leave details.
   * @param leavId the leave id of the employee
   * @return the leave details object
   */
  @SqlQuery("SELECT * FROM LEAVE_DETAILS WHERE LEV_ID = :leavId")
  @Mapper(LeaveDetailsMapper.class)
  LeaveDetails findLeavId(@Bind("leavId") int leavId);

    /**
     * @return returns the Updation result.
     * @param empId the id of the employee.
     * @param days the days to be deducted from leave balance.
     */
  @SqlUpdate("Update EMPLOYEE set EMP_LEAVE_BALANCE = :days where EMP_ID = :empId")
    int updateBalance(@Bind("days") float days, @Bind("empId") int empId);

    /**
     * close with no args is used to close the connection.
     */
  void close();
}
