package com.hexaware.ftp16.model;

/**
 * Userdefined class for leave Status.
 * @author hexware
 */
public enum LeaveStatus {

    /**
     * Types of Leave Status.
     */
    PENDING, APPROVED, DENIED
}
