package com.hexaware.ftp16.persistence;

import com.hexaware.ftp16.model.Employee;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

import java.util.List;

/**
 * The DAO class for employee.
 */
public interface EmployeeDAO  {
  /**
   * return all the details of all the employees.
   * @return the employee array
   */
  @SqlQuery("SELECT * FROM EMPLOYEE")
  @Mapper(EmployeeMapper.class)
  List<Employee> list();

  /**
   * return all the details of the selected employee.
   * @param empID the id of the employee
   * @return the employee object
   */
  @SqlQuery("SELECT * FROM EMPLOYEE WHERE EMP_ID = :empID")
  @Mapper(EmployeeMapper.class)
  Employee find(@Bind("empID") int empID);

  /**
   * @param empID the id of the employee
   * @param leaveAvalBal the leave Balance to be updated
   * @return the updation result
   */
  @SqlUpdate("update EMPLOYEE set EMP_LEAVE_BALANCE = :leavAvalBal where EMP_ID = :empID")
  int updateLeave(@Bind("leavAvalBal") float leaveAvalBal, @Bind("empID") int empID);
  /**
   * return all the details of the selected employee.
   * @param empID the id of the employee
   * @return the employee object
   */
  @SqlQuery("SELECT * FROM EMPLOYEE WHERE MGR_ID = :empID")
  @Mapper(EmployeeMapper.class)
  List<Employee> findManager(@Bind("empID") int empID);

  /**
  * close with no args is used to close the connection.
  */
  void close();
}
