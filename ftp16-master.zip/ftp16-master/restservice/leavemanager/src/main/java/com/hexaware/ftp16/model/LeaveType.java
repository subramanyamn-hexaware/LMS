package com.hexaware.ftp16.model;

/**
 * Userdefined class for leave type.
 * @author hexware
 */
public enum LeaveType {

    /**
     *Earned Leave.
     */
    EL;
}
