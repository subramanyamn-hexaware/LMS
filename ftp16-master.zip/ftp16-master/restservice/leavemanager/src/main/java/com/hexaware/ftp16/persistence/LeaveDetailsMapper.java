package com.hexaware.ftp16.persistence;

import org.skife.jdbi.v2.tweak.ResultSetMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.skife.jdbi.v2.StatementContext;

import com.hexaware.ftp16.model.LeaveDetails;
import com.hexaware.ftp16.model.LeaveStatus;
import com.hexaware.ftp16.model.LeaveType;
/**
 * Mapper class to map from result set to leavedetails object.
 */
public class LeaveDetailsMapper implements ResultSetMapper<LeaveDetails> {
  /**
   * @param idx the index
   * @param rs the resultset
   * @param ctx the context
   * @return the mapped leavedetails object
   * @throws SQLException in case there is an error in fetching data from the resultset
   */

  public final LeaveDetails map(final int idx, final ResultSet rs, final StatementContext ctx) throws SQLException {
    /**
     * @return leavedetails
     */
    return new LeaveDetails(rs.getInt("LEV_ID"), rs.getDate("LEV_FROM_DATE"),
                                rs.getDate("LEV_TO_DATE"), rs.getFloat("LEV_NO_OF_DAYS"),
                                    rs.getDate("LEV_APPLIED_DATE"),
                                        LeaveStatus.valueOf(rs.getString("LEV_STATUS")), rs.getString("LEV_REASON"),
                                            rs.getString("LEV_COMMENTS"), LeaveType.valueOf(rs.getString("LEV_TYPE")),
                                                rs.getInt("EMP_ID"));
  }
}
