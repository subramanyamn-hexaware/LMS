package com.hexaware.ftp16.util;

import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.hexaware.ftp16.model.LeaveDetails;
import com.hexaware.ftp16.model.Employee;

/**
 * Class CliMain provides the command line interface to the leavemanagement
 * application.
 */
public class CliMain {
  private Scanner option = new Scanner(System.in, "UTF-8");

  private void mainMenu() {
    try {
      System.out.println("Leave Management System");
      System.out.println("-----------------------");
      System.out.println("1. List All Employees Info");
      System.out.println("2. Display Employee Info");
      System.out.println("3. Apply Leave");
      System.out.println("4. View Leave History");
      System.out.println("5. View Pending Leave Applications");
      System.out.println("6. Approval/Deny Leave");
      System.out.println("7. Exit");
      System.out.println("Enter your choice:");
      int menuOption = option.nextInt();
      mainMenuDetails(menuOption);
    } catch (Exception e) {
      System.out.println("Enter valid Data");
    }
  }

  private void mainMenuDetails(final int selectedOption) {
    switch (selectedOption) {
      case 1:
        listEmployeeDetails();
        break;
      case 2:
        listEmployeeDetail();
        break;
      case 3:
        applyLeave();
        break;
      case 4:
        viewLeaveHistory();
        break;
      case 5:
        viewPendingLeave();
        break;
      case 6:
        approveDenyLeave();
        break;
      case 7:
      // halt since normal exit throws a stacktrace due to jdbc threads not responding
        Runtime.getRuntime().halt(0);
      default:
        System.out.println("Choose either 1, 2, 3, 4, 5, 6 or 7");
    }
    mainMenu();
  }

  private void listEmployeeDetail() {
    try {
      System.out.println("Enter an Employee Id");
      int empId = option.nextInt();
      Employee employee = Employee.listById(empId);
      if (employee == null) {
        System.out.println("Sorry, No such employee");
      } else {
        System.out.println("EmpId\tEmpName\tEmpMobile\tEmpMail\t\t\tEmpDept\t\tEmpJoinDate\tMgrId\tEmpLeavBal\n");
        System.out.println(employee.getEmpId() + "\t" + employee.getEmpName() + "\t" + employee.getEmpMobile() + "\t"
            + employee.getEmpMail() + "\t" + employee.getEmpDept() + "\t" + employee.getEmpJoinDate() + "\t"
            + employee.getMgrId() + "\t" + (int) employee.getEmpLeavBal());
      }
    } catch (Exception e) {
      System.out.println("Please Enter Valid Input");
      option.nextLine();
    }
  }

  private void listEmployeeDetails() {
    Employee[] employee = Employee.listAll();
    System.out.println("EmpId\tEmpName\tEmpMobile\tEmpMail\t\t\tEmpDept\t\tEmpJoinDate\tMgrId\tEmpLeavBal\n");
    for (Employee e : employee) {
      System.out.println(e.getEmpId() + "\t" + e.getEmpName() + "\t" + e.getEmpMobile() + "\t" + e.getEmpMail() + "\t"
          + e.getEmpDept() + "\t" + e.getEmpJoinDate() + "\t" + e.getMgrId() + "\t" + (int) e.getEmpLeavBal());
    }
  }

  private void approveDenyLeave() {
    int empId = 0;
    try {
      System.out.println("Enter your employee ID:");
      empId = option.nextInt();
      Employee employee = Employee.listById(empId);
      if (employee == null) {
        throw new IllegalArgumentException("Sorry, No such employee");
      } else {
        System.out.println("Enter the leave ID:");
        option.nextLine();
        int leavId = 0;
        leavId = option.nextInt();
        try {
          System.out.println("Enter the leave status: (APPROVED/DENIED/PENDING)");
          String strStatus = option.next();
          option.nextLine();
          System.out.println("Enter the mngr cmnts:");
          String cmnts = option.nextLine();
          String result = LeaveDetails.approveDenyValidation(leavId, empId, strStatus, cmnts);
          System.out.println(result);
        } catch (Exception e) {
          System.out.println(e.getMessage());
        }
      }
    } catch (InputMismatchException e) {
      System.out.println("Please Enter Valid Input");
      option.nextLine();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      option.nextLine();
    }
  }

  /**
   * To list the pending leave.
   *
   */
  private void viewPendingLeave() {
    System.out.println("Enter your Employee Id : ");
    String s = option.next();
    int empId = 0;
    try {
      empId = Integer.parseInt(s);
      Employee employee = Employee.listById(empId);
      if (employee == null) {
        System.out.println("Sorry, No such employee");
      } else {
        Employee[] employee1 = Employee.listManager(empId);
        if (employee1.length == 0) {
          System.out.println("You are Not a Manager");
        } else {
          LeaveDetails[] levList = LeaveDetails.pendingList(empId);
          if (levList.length == 0) {
            System.out.println("No Such Records");
          } else {
            System.out.println(
                "Leave id" + "\t" + "Leave type" + "\t" + "Start Date" + "\t" + "End Date" + "\t" + "noOfDays" + "\t"
                    + "Applied Date" + "\t" + "Leave Status" + "\t" + "Reason" + "\t\t" + "comments" + " " + "empId");
            for (LeaveDetails ld : levList) {
              System.out.println(ld);
            }
          }
        }
      }
    } catch (Exception e) {
      System.out.println("Please Enter Valid Input");
    }
  }

  private void applyLeave() {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    System.out.println("Enter your Employee Id : ");
    try {
      int empId = option.nextInt();
      Employee employee = Employee.listById(empId);
      if (employee == null) {
        throw new IllegalArgumentException("Sorry, No such employee");
      } else {
        System.out.println("Leave Balance : " + (int) employee.getEmpLeavBal());
        System.out.println("Enter The Required Leave Details");
        System.out.println("Enter No Of Days : ");
        int days = option.nextInt();
        System.out.println("Enter Start Date (YYYY-MM-DD) : ");
        String startDate = option.next();
        System.out.println("Enter End Date (YYYY-MM-DD) : ");
        String endDate = option.next();
        option.nextLine();
        System.out.println("Please Enter your reasons for Leave : ");
        String reason = option.nextLine();
        String result = Employee.applyLeaveValidation(empId, startDate, endDate, days, reason);
        System.out.println(result);
      }
    } catch (Exception e) {
      if (e.getMessage() == null) {
        System.out.println("Please Enter Valid Input");
      } else {
        System.out.println(e.getMessage());
      }
      option.nextLine();
    }
  }

  private void viewLeaveHistory() {
    try {
      System.out.println("Enter your Employee Id : ");
      int employeelevid = option.nextInt();
      Employee employee = Employee.listById(employeelevid);
      if (employee == null) {
        System.out.println("Sorry, No such employee");
      } else {
        LeaveDetails[] leavedetails = LeaveDetails.listhistory(employeelevid);
        if (leavedetails.length == 0) {
          System.out.println("No Leave History exists");
        } else {
          System.out.println("Leave id" + "\t" + "Leave type" + "\t" + "Leave Status" + "\t" + "Applied Date" + "\t"
              + "Reason" + "\t\t" + "comments" + "\t" + "Start Date" + "\t" + "End Date" + "\t" + "noOfDays");
          for (LeaveDetails l : leavedetails) {
            System.out.println(l.getLeavId() + "\t\t" + l.getLeavType() + "\t\t" + l.getStatus() + "\t\t"
                + l.getAppliedDate() + "\t" + l.getReason() + "\t\t" + l.getComments() + "\t\t" + l.getLeavFromDate()
                + "\t" + l.getLeavToDate() + "\t" + (int) l.getNoOfDays());
          }
        }
      }
    } catch (Exception e) {
      System.out.println("Please Enter Valid Input");
      option.nextLine();
    }
  }

  /**
   * The main entry point.
   * @param ar the list of arguments
   */
  public static void main(final String[] ar) {
    CliMain mainObj = new CliMain();
    mainObj.mainMenu();
  }

}
