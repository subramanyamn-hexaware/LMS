package com.hexaware.ftp16.model;

import com.hexaware.ftp16.persistence.DbConnection;
import com.hexaware.ftp16.persistence.EmployeeDAO;

import java.util.Objects;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;

/**
 * Employee class to store employee personal details.
 * @author hexware
 */
public class Employee {

/**
   *empId to store employee id.
   */
  private int empId;
  private String empName; //empName to store employee Name
  private long empMobile; //empMobile to store employee Mobile
  private String empMail; //empMail to store employee Email
  private String empDept; //empDept to store employee Department
  private Date empJoinDate; //empJoinDate to store employee Joining date
  private int mgrId; //mgrId to store manager Id
  private float empLeavBal; //empLeavBal to store employee leave Balance

  @Override
  public final boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Employee emp = (Employee) obj;
    if (Objects.equals(empId, emp.empId) && Objects.equals(empName, emp.empName)
        && Objects.equals(empMobile, emp.empMobile) && Objects.equals(empMail, emp.empMail)
         && Objects.equals(empDept, emp.empDept) && Objects.equals(empJoinDate, emp.empJoinDate)
          && Objects.equals(mgrId, emp.mgrId)  && Objects.equals(empLeavBal, emp.empLeavBal)) {
      return true;
    }
    return false;
  }

  @Override
  public final int hashCode() {
    return Objects.hash(empId, empName, empDept, empJoinDate, empMail, empMobile, mgrId);
  }

  @Override
  public final String toString() {
    return " EmpId: " + empId + " EmpName: " + empName + " EmpDept: "
              + empDept + " EmpJoiningDate: " + empJoinDate + " EmpMail: "
                + empMail + " EmpMobile: " + empMobile + " MgrId: "
                  + mgrId + " EmpLeaveBal: " + (int) empLeavBal;
  }

  /**
   * @param argEmpId to initialize employee id.
   */
  public Employee(final int argEmpId) {
    this.empId = argEmpId;
  }

  /**
   * @param argEmpId to initialize employee id.
   * @param argEmpName to initialize employee name.
   * @param argEmpMobile to initialize employee Mobile.
   * @param argEmpMail to initialize employee Mail.
   * @param argEmpDept to initialize employee Department.
   * @param argEmpJoinDate to initialize employee Joining date.
   * @param argMgrId to initialize employee Manager Id.
   * @param argEmpLeavBal to initialize employee LeaveBalance.
   */
  public Employee(final int argEmpId, final String argEmpName,
                    final long argEmpMobile, final String argEmpMail,
                      final String argEmpDept, final Date argEmpJoinDate,
                        final int argMgrId, final float argEmpLeavBal) {
    this.empId = argEmpId;
    this.empName = argEmpName;
    this.empMobile = argEmpMobile;
    this.empMail = argEmpMail;
    this.empDept = argEmpDept;
    this.empJoinDate = argEmpJoinDate;
    this.mgrId = argMgrId;
    this.empLeavBal = argEmpLeavBal;
  }

  /**
   * Default constructor for employee.
   */
  public Employee() {
  }



  /**
   * Gets the EmployeeId.
   * @return this Employee's ID.
   */
  public final int getEmpId() {
    return empId;
  }

  /**
   * Gets the EmployeeName.
   * @return this Employee's Name.
   */
  public final String getEmpName() {
    return empName;
  }

  /**
   * Gets the EmployeeMobile.
   * @return this Employee's MobileNumber.
   */
  public final long getEmpMobile() {
    return empMobile;
  }

  /**
   * Gets the EmployeeMail.
   * @return this Employee's Email.
   */
  public final String getEmpMail() {
    return empMail;
  }

  /**
   * Gets the EmployeeDepartment.
   * @return this Employee's Department.
   */
  public final String getEmpDept() {
    return empDept;
  }

  /**
   * Gets the EmployeeJoiningDate.
   * @return this Employee's Joining Date.
   */
  public final Date getEmpJoinDate() {
    return empJoinDate;
  }

  /**
   * Gets the EmployeeManagerID.
   * @return this Employee's ManagerID.
   */
  public final int getMgrId() {
    return mgrId;
  }

  /**
   * Gets the Employee Leave Balance.
   * @return this Employee's Leave Balance.
   */
  public final float getEmpLeavBal() {
    return empLeavBal;
  }

  /**
   *
   * @param argEmpId to set employee id.
   */
  public final void setEmpId(final int argEmpId) {
    this.empId = argEmpId;
  }

  /**
   *
   * @param argEmpName to set employee Name.
   */
  public final void setEmpName(final String argEmpName) {
    this.empName = argEmpName;
  }

  /**
   *
   * @param argEmpMobile to set employee MobileNumber.
   */
  public final void setEmpMobile(final long argEmpMobile) {
    this.empMobile = argEmpMobile;
  }

  /**
   *
   * @param argEmpMail to set employee EmailId.
   */
  public final void setEmpMail(final String argEmpMail) {
    this.empMail = argEmpMail;
  }

  /**
   *
   * @param argEmpDept to set employee Department.
   */
  public final void setEmpDept(final String argEmpDept) {
    this.empDept = argEmpDept;
  }

  /**
   *
   * @param argEmpLeavBal to set employee Leave Balance.
   */
  public final void setEmpLeavBal(final float argEmpLeavBal) {
    this.empLeavBal = argEmpLeavBal;
  }

  /**
   *
   * @param argEmpJoinDate to set employee Joining date.
   */
  public final void setEmpJoinDate(final Date argEmpJoinDate) {
    this.empJoinDate = argEmpJoinDate;
  }

  /**
   *
   * @param argEmpMgrId to set employee ManagerId.
   */
  public final void setEmpMgrId(final int argEmpMgrId) {
    this.mgrId = argEmpMgrId;
  }

  /**
   * @return The dao for employee.
   */
  public static EmployeeDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(EmployeeDAO.class);
  }

  /**
   * list all employee details.
   * @return all employees' details
   */
  public static Employee[] listAll() {

    List<Employee> es = dao().list();
    return es.toArray(new Employee[es.size()]);
  }

  /**
   * @param empId the id of the employee
   * @param fromDate the start date of leave
   * @param toDate the end date of leave
   * @param days the no of days leave applied
   * @param reason leave reason
   * @return returns the insertion result
   */
  public static String insertLeave(final int empId, final String fromDate,
                                   final String toDate, final int days, final String reason) {
    String result = "";
    boolean isManager = false;
    Employee employee = Employee.listById(empId);
    LeaveStatus levStatus = LeaveStatus.PENDING;
    float curLevBal = employee.getEmpLeavBal();
    if (employee.getMgrId() == 0) {
      levStatus = LeaveStatus.APPROVED;
      isManager = true;
    }
    if (LeaveDetails.dao().insert(LeaveType.EL, fromDate, toDate, days, reason, empId, levStatus) > 0) {
      float leavBal = curLevBal - days;
      if (LeaveDetails.dao().updateBalance(leavBal, empId) > 0) {
        if (isManager) {
          result = "Applied Leave has been Approved.";
        } else {
          result = "Applied Leave sent for Approval.";
        }
      } else {
        result = "Updation Error";
      }
    }
    return result;
  }

  /**
   * @param empId the id of the employee.
   * @param fromDate the start date of leave
   * @param toDate the end date of leave
   * @param days the no of days leave applied
   * @param reason leave reason
   * @return the result string of apply leave
   * @throws Exception on validating data
   */
  public static String applyLeaveValidation(final int empId, final String fromDate,
                                            final String toDate, final int days, final String reason)
                                              throws Exception {
    String result = "";
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    try {
      Employee employee = Employee.listById(empId);
      if (employee == null) {
        result = "Sorry, No such employee";
      } else {
        float leaveBal = employee.getEmpLeavBal();
        if (leaveBal > 0) {
          if (days < 0) {
            result = "Please enter a Positive value.";
          } else if (days == 0) {
            result = "You cannot apply leave for 0 days. Please enter valid Input";
          } else if (leaveBal >= days) {
            Date strtDate = stringToDate(fromDate);
            Date endDate = stringToDate(toDate);
            verifyApplyDates(strtDate, endDate);
            compareDayDiff(strtDate, endDate, days);
            verifydates(fromDate, toDate, empId);
            result = insertLeave(empId, sdf.format(strtDate), sdf.format(endDate), days, reason);
          } else {
            result = "You do not have sufficient leave balance to apply.";
          }
        } else {
          result = "You do not have sufficient leave balance to apply.";
        }
      }
    } catch (Exception e) {
      result = e.getMessage();
      //result = e.toString();
    }
    return result;
  }


  /**
   * Verify the Leave ApplicationDates.
   * @param startDate Leave Application fromDate.
   * @param endDate Leave Application toDate.
   * @throws Exception on invalid dates.
   */
  public static void verifyApplyDates(final Date startDate, final Date endDate) throws Exception {
    if (!endDate.after(startDate) && !endDate.equals(startDate)) {
      throw new IllegalArgumentException("End Date must be greater than Start Date");
    }
  }

  /**
   * Verify the Leave ApplicationDates.
   * @param empId the id of the employee
   * @param startDate Leave Application fromDate.
   * @param endDate Leave Application toDate.
   * @throws Exception on Overlapping dates.
   */
  public static void verifydates(final String startDate, final String endDate, final int empId) throws Exception {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    Date fromDate = sdf.parse(startDate);
    Date toDate = sdf.parse(endDate);
    LeaveDetails[] leavedetails = LeaveDetails.listhistory(empId);
    for (LeaveDetails l : leavedetails) {
      if (fromDate.compareTo(l.getLeavFromDate()) >= 0 && fromDate.compareTo(l.getLeavToDate()) <= 0
            || toDate.compareTo(l.getLeavFromDate()) >= 0 && toDate.compareTo(l.getLeavToDate()) <= 0
              || l.getLeavFromDate().compareTo(fromDate) > 0 && l.getLeavToDate().compareTo(toDate) < 0) {
        throw new IllegalArgumentException("You already applied leave in these dates.");
      }
    }
  }

  /**
   * list employee details by id.
   * @param empId to get employee details.
   * @return Employee
   */
  public static Employee[] listManager(final int empId) {
    List<Employee> ld = dao().findManager(empId);
    return ld.toArray(new Employee[ld.size()]);
  }

  /**
   * list employee details by id.
   * @param empID to get employee details.
   * @return dao.
   */
  public static Employee listById(final int empID) {
    return dao().find(empID);
  }
  /**
   * @param leavAvalBal balance
   * @param empId employeeid
   * @return status
   */
  public static int leaveBal(final float leavAvalBal, final int empId) {
    return dao().updateLeave(leavAvalBal, empId);
  }

  /**
   * Verify the Days provided with dates.
   * @param fromDate Leave Application fromDate.
   * @param toDate Leave Application toDate.
   * @param days Days entered by user
   * @throws Exception on invalid No Of days input.
   */
  public static void compareDayDiff(final Date fromDate, final Date toDate, final int days) throws Exception {
    long dayDiff = (toDate.getTime() - fromDate.getTime()) / 86400000;
    dayDiff += 1;
    if (dayDiff != days) {
      throw new IllegalArgumentException("No Of Days does not match.");
    }
  }

  /**
   * Convert String to date.
   * @param dateString String to be converted.
   * @return converted Date
   * @throws Exception on unparsable date string.
   */
  public static Date stringToDate(final String dateString) throws Exception {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);
    try {
      return sdf.parse(dateString);
    } catch (Exception e) {
      throw new IllegalArgumentException("Enter Valid Date Format");
    }
  }

}
