# Week #7: Course Materials

The objective of week #5 is to get the employee details to the web ui in the list. Also to add change the unit and system tests.

## Angular 4

## Karma/Jasmine

## Selenium/Protractor

# Week #7

    * Sprint goals
       * Jira Task: To start on the web interface and complete the basic screens - login/dashboard screens
     
# Reading material

## Must-Read

### Angular
  * Typescript
    * Promises: https://basarat.gitbooks.io/typescript/docs/promise.html
  * Angular Intro
    * https://www.youtube.com/watch?v=KhzGSHNhnbI

## Nice-To-Read

## Go-Deep

  
