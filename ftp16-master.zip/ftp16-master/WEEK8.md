# Week #8: Course Materials

The objective of week #8 is to complete the Web UI implementation for all the functionalities. And complete the tests: The jasmine/karma tests and the protractor/selenium tests.

# Week #8

    * Sprint goals
       * Jira Task: Complete UI implementation w/ Angular, unit tests and integration tests
     
# Reading material

## Must-Read

## Nice-To-Read

## Go-Deep

  
