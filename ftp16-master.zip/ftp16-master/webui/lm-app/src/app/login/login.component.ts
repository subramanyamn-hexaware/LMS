import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  empId : string;
  mngId : string;
  password : string;

  constructor(private router : Router) { }

  validate() {
    if(this.empId == localStorage.getItem("employeeId")) {
      this.router.navigate(['/dashboard']);
    }
  }

  EmployeeNavigate() {
    this.router.navigate(['/']);
  }

  ngOnInit() {
    this.empId = localStorage.getItem("employeeId");
    // this.mngId = localStorage.getItem("mgrId");
  }

}
