import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
  providers: [ EmployeeService ]
})
export class EmployeesComponent implements OnInit {

  constructor(private employeeService: EmployeeService , private router : Router) { }
  
    title = 'Leave Management Application';
    employees: Employee[];
  
    getEmployees(): void {
        this.employeeService.getEmployees().then(employees => {
          console.log('getEmployees promise resolved : ' + employees.length);
          this.employees = employees;
        }
      );
    }

    loginNavigation(empId,mgrId) {
      localStorage.setItem("employeeId",empId);
      localStorage.setItem("managerId",mgrId);
      this.router.navigate(['\login']);
    }
  
    ngOnInit(): void {
      this.getEmployees();
    }

}
