import { Component, OnInit } from '@angular/core';
import { LeaveService } from "../leave.service";
import { LeaveDetails } from "../leaveDetails";
import { Observable } from "rxjs/Rx";
import { Router } from "@angular/router";

@Component({
  selector: 'app-my-leave-applications',
  templateUrl: './my-leave-applications.component.html',
  styleUrls: ['./my-leave-applications.component.css'],
  providers: [LeaveService]
})
export class MyLeaveApplicationsComponent implements OnInit {
  //model = new LeaveDetails();
  empId : number;
  lev : Observable<LeaveDetails[]>;
  constructor(private _Serv:LeaveService, private _route : Router) { 
    this.empId=parseInt(localStorage.getItem("employeeId"));
    this.lev = this._Serv.getLeaveDetails(this.empId);
  }
  ApplyNewleave() {
    this._route.navigate(['/Applyleave']);

  }

  ngOnInit() {
  }

}
