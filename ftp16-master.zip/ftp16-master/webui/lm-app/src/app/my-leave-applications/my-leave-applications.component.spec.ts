import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyLeaveApplicationsComponent } from './my-leave-applications.component';

describe('MyLeaveApplicationsComponent', () => {
  let component: MyLeaveApplicationsComponent;
  let fixture: ComponentFixture<MyLeaveApplicationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyLeaveApplicationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyLeaveApplicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
