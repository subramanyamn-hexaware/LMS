import { Component, OnInit } from '@angular/core';
import {Employee} from '../employee';
import {Observable} from 'rxjs/Rx';
import {Router} from '@angular/router';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'app-manager-details',
  templateUrl: './manager-details.component.html',
  styleUrls: ['./manager-details.component.css']
})
export class ManagerDetailsComponent implements OnInit {

  manager : Observable<Employee>;
  constructor(private _userServ : EmployeeService,private _router:Router) { }

  ngOnInit() {
    this.manager=this._userServ.getManager(localStorage.getItem("managerId"));
  }

}
