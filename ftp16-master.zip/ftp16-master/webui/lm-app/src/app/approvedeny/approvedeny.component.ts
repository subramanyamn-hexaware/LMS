import { Component, OnInit } from '@angular/core';
import { LeaveDetails } from '../LeaveDetails';
import { LeaveService } from '../leave.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Observable } from 'rxjs/Rx';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-approvedeny',
  templateUrl: './approvedeny.component.html',
  styleUrls: ['./approvedeny.component.css'],
  providers: [ LeaveService , EmployeeService ]
})
export class ApprovedenyComponent implements OnInit {
    empData : Observable<Employee>;
    leaveDet = new LeaveDetails();
    command : string;
    msg: String;
    empId : string;

    status(command) {
        this.leaveDet.status = command;
    }
    cancel() {
        this._route.navigate(['/dashboard'])
    }
    home() {
        this._route.navigate(['/dashboard'])
    }
    isValidFormSubmitted = false;
    approveDeny(form: NgForm) {
        this.isValidFormSubmitted = false;
        if (form.invalid) {
            return;
        }
        this.leavServ.approveDeny(this.leaveDet,this.empId).subscribe(
            d => {
                this.msg = d;
                
            },
            err => {
                this.msg = err;
               
                console.log(err);
            }
        )
        this.isValidFormSubmitted = true;
        setTimeout(() => {
          
            this._route.navigate(['/dashboard'])
          } 
        , 3000);
    }
    constructor(private leavServ : LeaveService,private empServ : EmployeeService,private _route: Router) { 
    this.leaveDet.reason = localStorage.getItem("levReason");
    this.empData=this.empServ.getemployee(localStorage.getItem("levEmpId"));
    this.leaveDet.leavType = localStorage.getItem("levType");
    this.leaveDet.leavId = Number(localStorage.getItem("levId"));
    this.leaveDet.empId=parseInt(localStorage.getItem("employeeId"));
    this.leaveDet.leavFromDate=localStorage.getItem("levFromDate");
    this.leaveDet.leavToDate=localStorage.getItem("levToDate");
    this.leaveDet.noOfDays=Number(localStorage.getItem("levDays"));
    this.empId = localStorage.getItem("employeeId");
    leavServ.approveDeny(this.leaveDet,this.empId);
  }

  ngOnInit() {
  }

}