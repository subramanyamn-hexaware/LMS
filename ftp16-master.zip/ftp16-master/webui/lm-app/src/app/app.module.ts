import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { OrderModule } from 'ngx-order-pipe';
import {EmployeeService} from './employee.service';

import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ApplyleaveComponent } from './applyleave/applyleave.component';
import { PendingleavesComponent } from './pendingleaves/pendingleaves.component';
import { ApprovedenyComponent } from './approvedeny/approvedeny.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ManagerDetailsComponent } from './manager-details/manager-details.component';
import { MyLeaveApplicationsComponent } from './my-leave-applications/my-leave-applications.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    LoginComponent,
    DashboardComponent,
    ApplyleaveComponent,
    EmployeeDetailsComponent,
    PendingleavesComponent,
    ApprovedenyComponent,
    EmployeeDetailsComponent,
    ManagerDetailsComponent,
    MyLeaveApplicationsComponent
  ],
  imports: [
    BrowserModule,FormsModule,OrderModule,
    HttpModule,
    RouterModule.forRoot([{path:'login', component:LoginComponent},
    {path:'dashboard', component:DashboardComponent},
    {path:'Applyleave',component:ApplyleaveComponent},
    {path:'pendingLeave', component:PendingleavesComponent},
    {path:'approvedeny', component:ApprovedenyComponent},
    {path:'', component:EmployeesComponent},
    {path:'EmployeeDetails', component:EmployeeDetailsComponent},
    {path:'ManagerDetails', component:ManagerDetailsComponent},
    {path:'mylevapp', component:MyLeaveApplicationsComponent}

  
  ])
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
