export class LeaveDetails {
    public leavId : Number;
    public leavFromDate : string;
    public leavToDate : string;
    public noOfDays : Number;
    public appliedDate : string;
    public status : string;
    public reason : string;
    public comments : string;
    public leavType : string;
    public empId : Number;
}