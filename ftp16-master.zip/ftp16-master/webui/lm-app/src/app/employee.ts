export class Employee {
  public empId : number;
  public empName : string;
  public empMobile : number;
  public empMail : string;
  public empDept : string;
  public empJoinDate : string;
  public mgrId : number;
  public empLeavBal : number;

  constructor(id: number,
    name: string,
    mobile: number,
    mail: string,
    dept: string,
    joinDate: string,
    mgrId: number,
    leavBal: number) {
      this.empId = id;
      this.empName = name;
      this.empMobile = mobile;
      this.empMail = mail;
      this.empDept = dept;
      this.empJoinDate = joinDate;
      this.mgrId = mgrId;
      this.empLeavBal = leavBal;
  }
}
