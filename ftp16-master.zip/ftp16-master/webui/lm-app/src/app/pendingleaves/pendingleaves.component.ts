import { Component, OnInit } from '@angular/core';

import { LeaveDetails } from '../LeaveDetails';
import { LeaveService } from '../leave.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Observable } from 'rxjs/Rx'
import { OrderModule } from 'ngx-order-pipe';
import { Router } from '@angular/router'

@Component({
  selector: 'app-pendingleaves',
  templateUrl: './pendingleaves.component.html',
  styleUrls: ['./pendingleaves.component.css'],
  providers: [ LeaveService , EmployeeService ]
})
export class PendingleavesComponent implements OnInit {

  PendingLeaves : Observable<LeaveDetails[]>;
  employeeDet : Employee;
  selectedRow : number;
  leavDet : LeaveDetails;
  employee : Observable<Employee[]>;
  mgr : string;
  buttonStatus : boolean;  
  setClickedRow : Function;
  isMgr : boolean = false;

  constructor(private leavServ : LeaveService,private empServ : EmployeeService,public router : Router) {
    this.employee = this.empServ.getData();
    this.PendingLeaves = this.leavServ.getPendingLeaves();
    this.mgr = localStorage.getItem("employeeId");

    this.setClickedRow = function(index){
      this.selectedRow = index;
  }
   }

   setTrue() {
    this.isMgr = true;
  }

   getRowDetails(empDet, leavDet) {
    this.employeeDet = empDet;
    this.leavDet = leavDet;
    this.buttonStatus = true;
    localStorage.setItem("levEmpId",String(this.employeeDet.empId));
    localStorage.setItem("levId",String(this.leavDet.leavId));
    localStorage.setItem("levFromDate",String(this.leavDet.leavFromDate));
    localStorage.setItem("levToDate",String(this.leavDet.leavToDate));
    localStorage.setItem("levType",String(this.leavDet.leavType));
    localStorage.setItem("levStatus",String(this.leavDet.status));
    localStorage.setItem("levReason",String(this.leavDet.reason));
    localStorage.setItem("levDays",String(this.leavDet.noOfDays));
   }

   navigateApproveDeny() {
     this.router.navigate(['\approvedeny']);
   }

  ngOnInit() {
    this.buttonStatus = false;
  }

}
