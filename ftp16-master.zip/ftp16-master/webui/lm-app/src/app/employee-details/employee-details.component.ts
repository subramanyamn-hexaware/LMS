import { Component, OnInit } from '@angular/core';
import {Employee} from '../employee';
import {Observable} from 'rxjs/Rx';
import {Router} from '@angular/router';
import {EmployeeService} from '../employee.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  
  employee : Observable<Employee>;
  constructor(private _userServ : EmployeeService,private _router:Router) { }

  ngOnInit() {
    this.employee=this._userServ.getemployee(localStorage.getItem("employeeId"));
  }
}

