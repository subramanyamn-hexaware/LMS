import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { LeaveDetails } from './leaveDetails'

@Injectable()
export class LeaveService {

  constructor(private http : Http) { }


  getPendingLeaves() : Observable<LeaveDetails[]> {
    return this.http.get("http://localhost:8080/ftp16/api/leaveDetailsRestService/"+ localStorage.getItem("employeeId") +"/listPendingLeaves").
    map((res : Response) => res.json()).
    catch((error:any)=>Observable.throw(error.json().error || 'Not Found'))
  }

  approveDeny(leavDet:LeaveDetails, empId) : Observable<string> { 
    return this.http.post("http://localhost:8080/ftp16/api/leaveDetailsRestService/"+empId+"/approvedeny",leavDet).map(response=>response.text())
    .catch((error:any)=>Observable.throw(error.toString() || 'Server Error'));
  }

  getLeaveDetails(empId): Observable<LeaveDetails[]> {
    return this.http.get(" http://localhost:8080/ftp16/api/leaveDetailsRestService/"+empId+"/leaveHistory")
    .map((res: Response) => res.json())
 .catch((error: any) =>
  Observable.throw(error.json().error || 'Server error'));
 } 

}
