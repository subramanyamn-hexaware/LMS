import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  managerId:number;
  ceomessage:string;
  ceo:boolean=true;
  constructor() { }

  
  ngOnInit() {
    this.managerId = Number(localStorage.getItem("managerId"));
    if(this.managerId==0){
      this.ceomessage='You are not having any reporting manager'
      return this.ceo=false;
    }
  }

}
