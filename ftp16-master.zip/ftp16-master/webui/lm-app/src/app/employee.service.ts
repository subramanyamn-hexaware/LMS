import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

import { Http,Response } from '@angular/http';
import { Injectable } from '@angular/core';
import {Employee} from './employee';
import {LeaveDetails} from './leavedetails'


@Injectable()
export class EmployeeService {
    constructor(private http: Http) {
    }

    getEmployees(): Promise<Employee[]> {
        console.log('getEmployees called on employee.service');
        return this.http.get('http://localhost:8080/ftp16/api/employees')
        .toPromise()
        .then(response => response.json() as Employee[])
        .catch(this.handleError);
    }
    

    getData() : Observable<Employee[]> {
        return this.http.get('http://localhost:8080/ftp16/api/employees').
        map((res : Response) => res.json()).
        catch((error:any)=>Observable.throw(error.json().error || 'Not Found'))
    }

    getEmployeeDetails(empId) : Observable<Employee> {
        return this.http.get("http://localhost:8080/ftp16/api/employees/" + empId).
        map((res : Response) => res.json()).
        catch((error:any)=>Observable.throw(error.json().error || 'Not Found'))
      }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
    applyLeave(model:LeaveDetails):Observable<String>{
        
        alert(model.empId + " " +model.leavFromDate + " " +model.leavToDate + " " +model.noOfDays + " " +model.reason + " " +model.leavType);

        return this.http.post('http://localhost:8080/ftp16/api/leaveDetailsRestService/3001/applyforleave',model) 
         .map(response=>response.text())
         .catch((error:any) => Observable.throw(error.toString() || 'Server error'));
       }
       getemployee(employeeId) : Observable<Employee>
       {
         return this.http.get("http://localhost:8080/ftp16/api/employees/"+employeeId).
         map((res : Response) => res.json()).
         catch((error : any) =>
         Observable.throw(error.json().error || 'Not Found'));
       }

       getManager(managerId) : Observable<Employee>
       {
         return this.http.get("http://localhost:8080/ftp16/api/employees/"+managerId).
         map((res : Response) => res.json()).
         catch((error : any) =>
         Observable.throw(error.json().error || 'Not Found'));
       }
}

