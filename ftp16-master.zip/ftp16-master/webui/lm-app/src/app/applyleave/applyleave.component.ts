
import { Component, OnInit } from '@angular/core';

import {Router} from '@angular/router';

import { EmployeeService } from "../employee.service";
import { LeaveDetails } from "../leavedetails";

import { NgForm } from "@angular/forms";



@Component({
  selector: 'app-applyleave',
  templateUrl: './applyleave.component.html',
  styleUrls: ['./applyleave.component.css'],
  providers: [EmployeeService]
})

export class ApplyleaveComponent implements OnInit {

  empId: number;
  model=new LeaveDetails();
  msg:String;
  isValidFormSubmitted = false;
  
constructor(private router:Router, public applyLeaveService:EmployeeService) {
  this.model.empId = parseInt(localStorage.getItem("employeeId"));

  }

 
 calculateDays()
 {
    let date1: string=this.model.leavFromDate;
   
 let date2: string=this.model.leavToDate;
    
let diffInMs: number = Date.parse(date2) - Date.parse(date1);
    
let diffInHours: number = diffInMs / 1000 / 60 / 60/24;
   
 this.model.noOfDays=diffInHours + 1;
     }
 
 ngOnInit() {
  }

  
applyLeave(form: NgForm)
 
 {
      this.isValidFormSubmitted=false;
      
if(form.invalid)
{
    return; 
    }  

      this.applyLeaveService.applyLeave(this.model).subscribe(
      
          d => {
              this.msg=d;
              alert(this.msg);
          },
          err => { 
              this.msg=err;
              alert("error " +this.msg);
          }
      )
        
  }
  cancel() {
    this.router.navigate(['/dashboard']);
  }

}