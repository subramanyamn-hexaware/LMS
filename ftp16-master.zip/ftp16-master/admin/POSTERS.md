# Multi-tier architecture

# Software lifecycle with git/jira

# Markdown cheatsheet

# Git sheatsheet

